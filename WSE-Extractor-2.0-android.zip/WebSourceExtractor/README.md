# WSE Extractor 2.0 — Evidence-Driven Web Project Extraction Engine

اپ اندروید (Kotlin + Jetpack Compose) پیاده‌سازی‌کنندهٔ معماری ۴۴‌بخشی:
**EVIDENCE FIRST. RECONSTRUCTION SECOND. INFERENCE LAST.**

## ساخت

1. Android Studio (Ladybug+) را باز کنید و پوشهٔ `WebSourceExtractor` را Open کنید.
2. یا خط فرمان: `./gradlew :app:assembleDebug`
3. نیازمندی: JDK 17، Android SDK 36. خروجی: `app/build/outputs/apk/debug/app-debug.apk`

## نگاشت الگوریتم به کد

| بخش الگوریتم | فایل |
|---|---|
| §2 Evidence Ledger | `core/Models.kt` (EvidenceRecord) |
| §3 Content-addressed storage | `core/ArtifactStore.kt` (SHA-256، اشتراک artifact بین URLها) |
| §5/§6 Static + Graph | `acquire/StaticEngine.kt`, `HtmlParser.kt`, `core/ResourceGraph.kt` |
| §7 JS analysis (بدون اجرا) | `acquire/JsAnalyzer.kt` (import/dynamic/fetch/XHR/WS/Worker/SW) |
| §8 Source-Map + اعتبارسنجی | `acquire/SourceMapEngine.kt` (header/comment/companion/inline + VLQ) |
| §9/§10 Runtime امن | `acquire/RuntimeEngine.kt` (WebView ایزوله، hook شبکه/کنسول/route، بدون submit فرم) |
| §11 Framework detection | `acquire/FrameworkDetector.kt` (نسخه فقط وقتی اثبات‌پذیر) |
| §15 Secret detection + redact | `JsAnalyzer.scanSecrets` + `redactAll` |
| §17 Reconstruction با اولویت | `reconstruct/Reconstructor.kt` (source-map > URL > import > INFERRED) |
| §19 Convergence (PASS 0–8) | `acquire/Orchestrator.kt` (حلقه تا پایداری graph/API/trace) |
| §20 Snapshot + Diff | `Snapshot`، `snapshot/SnapshotDiff.kt` |
| §21 Completeness صادقانه | `Orchestrator` (هرگز «100% سورس» نمی‌گوید) |
| §22 Integrity | PASS 8 + `hashes.sha256` |
| §23/§24 Export + unified raw | `export/Exporter.kt` (ZIP با ‎_extraction/‎ project/‎ deployed/‎ source-maps/‎ network/) |
| §25/§26 درخت virtualized + raw lazy | `ui/ResultView.kt` (LazyColumn، فایل‌های بزرگ lazy) |
| §27 Offline | snapshot روی دیسک؛ تحلیل بدون شبکه |
| §28 Resume | `checkpoint.json` + hash-unchanged skip |
| §30 امنیت (SSRF/limits) | `core/SecurityGuard.kt` |
| §31 Android 16 | targetSdk 36، `enableEdgeToEdge()`، `enableOnBackInvokedCallback`، BackHandler، resizeable |
| §33 Battery modes | `BatteryMode` (Normal/Balanced/Deep → concurrency) |
| §34 Background | `work/ExtractionWorker.kt` (WorkManager expedited + dataSync FGS) |
| §36 Adaptive UI | `BoxWithConstraints` — <840dp تب + bottom nav، ‏≥840dp سه‌پنل |
| §37 داشبورد واقعی | `ui/App.kt` (شمارنده‌ها از state واقعی) |

## محدودیت‌های صادقانه (§44)

- سورس بک‌اند از روی پاسخ API استنباط نمی‌شود؛ فقط «backend visibility» گزارش می‌شود.
- بدون source map معتبر، فایل JS/CSS به‌عنوان `DEPLOYED_SOURCE`/`BUNDLED_SOURCE` برچسب می‌خورد، نه original.
- مسیرهای حدسی صریحاً `INFERRED` هستند.
- Runtime engine به WebView سیستم وابسته است؛ سایت‌هایی با Cloudflare/anti-bot سخت ممکن است acquisition ناقص داشته باشند — که با صداقت در completeness-report اعلام می‌شود.
- فقط روی هدف‌هایی استفاده کنید که مجاز به تحلیلشان هستید.

## تست دستی پیشنهادی (ماتریس §39/§40)

- سایت Vite/Next نمونه با و بدون source map
- چرخش صفحه، split-screen، gesture back، process death (Developer options → Don't keep activities) و resume
- پروژهٔ بزرگ (1000+ ریسورس) برای بررسی virtualization و حافظه
