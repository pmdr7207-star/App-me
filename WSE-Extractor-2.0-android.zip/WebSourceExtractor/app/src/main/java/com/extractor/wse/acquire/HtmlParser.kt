package com.extractor.wse.acquire

import com.extractor.wse.core.DiscoveryMethod
import com.extractor.wse.core.NodeType
import kotlinx.serialization.json.jsonObject

/** HTML resource discovery (spec §5): recursive URL extraction, base-aware resolution. */
object HtmlParser {

    data class Found(val url: String, val method: DiscoveryMethod, val hint: NodeType, val inlineSource: String? = null)

    private val attr = Regex("""(?:src|href|poster|action|data-src|data-href)\s*=\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE)
    private val srcset = Regex("""srcset\s*=\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE)
    private val linkRel = Regex("""<link[^>]*rel\s*=\s*["']([^"']+)["'][^>]*>""", RegexOption.IGNORE_CASE)
    private val linkHref = Regex("""href\s*=\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE)
    private val metaRefresh = Regex("""http-equiv\s*=\s*["']refresh["'][^>]*content\s*=\s*["'][^"']*url=([^"';]+)""", RegexOption.IGNORE_CASE)
    private val importMap = Regex("""<script[^>]*type\s*=\s*["']importmap["'][^>]*>(.*?)</script>""", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
    private val inlineScript = Regex("""<script(?![^>]*src\s*=)[^>]*>(.*?)</script>""", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
    private val inlineStyle = Regex("""<style[^>]*>(.*?)</style>""", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
    private val iframeSrc = Regex("""<iframe[^>]*src\s*=\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE)
    private val manifestLink = Regex("""<link[^>]*rel\s*=\s*["']manifest["'][^>]*href\s*=\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE)

    fun extract(html: String): List<Found> {
        val out = LinkedHashMap<String, Found>()

        fun add(u: String, m: DiscoveryMethod, h: NodeType) {
            if (u.length < 2048) out.putIfAbsent(u, Found(u, m, h))
        }

        for (m in attr.findAll(html)) {
            val u = m.groupValues[1]
            if (u.startsWith("data:") || u.startsWith("javascript:") || u.startsWith("#")) continue
            val hint = when (u.substringAfterLast('.').substringBefore('?').lowercase()) {
                "js", "mjs", "cjs" -> NodeType.SCRIPT
                "css" -> NodeType.STYLE
                "png", "jpg", "jpeg", "gif", "webp", "svg", "ico", "avif" -> NodeType.IMAGE
                "woff", "woff2", "ttf", "otf", "eot" -> NodeType.FONT
                "mp4", "webm", "mp3", "wav", "ogg" -> NodeType.MEDIA
                "json", "webmanifest", "map" -> NodeType.JSON
                "wasm" -> NodeType.WASM
                else -> NodeType.DOCUMENT
            }
            val method = if (hint == NodeType.SCRIPT) DiscoveryMethod.STATIC_SCRIPT
            else if (hint == NodeType.STYLE) DiscoveryMethod.STATIC_CSS
            else if (hint == NodeType.DOCUMENT) DiscoveryMethod.HTML
            else DiscoveryMethod.STATIC_ASSET
            add(u, method, hint)
        }

        for (m in srcset.findAll(html)) {
            m.groupValues[1].split(',').forEach { part ->
                part.trim().split(Regex("""\s+""")).firstOrNull()?.let { add(it, DiscoveryMethod.STATIC_ASSET, NodeType.IMAGE) }
            }
        }

        for (m in linkRel.findAll(html)) {
            val rel = m.groupValues[1].lowercase()
            val href = linkHref.find(m.value)?.groupValues?.get(1) ?: continue
            when {
                "modulepreload" in rel -> add(href, DiscoveryMethod.IMPORT, NodeType.SCRIPT)
                "manifest" in rel -> add(href, DiscoveryMethod.MANIFEST, NodeType.JSON)
                "preload" in rel || "prefetch" in rel -> add(href, DiscoveryMethod.STATIC_ASSET, NodeType.OTHER)
                "stylesheet" in rel -> add(href, DiscoveryMethod.STATIC_CSS, NodeType.STYLE)
                "icon" in rel -> add(href, DiscoveryMethod.STATIC_ASSET, NodeType.IMAGE)
            }
        }

        for (m in manifestLink.findAll(html)) add(m.groupValues[1], DiscoveryMethod.MANIFEST, NodeType.JSON)
        for (m in metaRefresh.findAll(html)) add(m.groupValues[1].trim(), DiscoveryMethod.META, NodeType.DOCUMENT)
        for (m in iframeSrc.findAll(html)) add(m.groupValues[1], DiscoveryMethod.HTML, NodeType.FRAME)

        // import maps (spec §5)
        for (m in importMap.findAll(html)) {
            runCatching {
                val o = com.extractor.wse.core.json.parseToJsonElement(m.groupValues[1]).jsonObject
                listOfNotNull(o["imports"]?.jsonObject, o["scopes"]?.jsonObject).forEach { table ->
                    table.entries.forEach { (_, v) ->
                        val s = v.toString().trim('"')
                        if (s.startsWith("/") || s.startsWith("http") || s.startsWith("."))
                            add(s, DiscoveryMethod.IMPORT_MAP, NodeType.SCRIPT)
                    }
                }
            }
        }

        // inline scripts/styles still analyzed for references (spec §7)
        for (m in inlineScript.findAll(html)) {
            val src = m.groupValues[1]
            if (src.length in 2..2_000_000)
                JsAnalyzer.scanJs(src).forEach { add(it.url, it.method, it.hint) }
        }
        for (m in inlineStyle.findAll(html)) {
            JsAnalyzer.scanCss(m.groupValues[1]).forEach { add(it.url, it.method, it.hint) }
        }

        return out.values.toList()
    }
}
