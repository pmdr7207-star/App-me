package com.extractor.wse.acquire

import com.extractor.wse.core.DiscoveryMethod
import com.extractor.wse.core.NodeType

/** Static reference extraction from JS/CSS/HTML source (spec §7 — no execution). */
object JsAnalyzer {

    data class Ref(val url: String, val method: DiscoveryMethod, val hint: NodeType = NodeType.OTHER)
    data class SecretHit(val kind: String, val redacted: String)

    private val patterns: List<Triple<Regex, DiscoveryMethod, NodeType>> = listOf(
        Regex("""import\s+[^'"]*?\sfrom\s*['"]([^'"]+)['"]""") to Triple(DiscoveryMethod.IMPORT, NodeType.SCRIPT),
        Regex("""import\s*\(\s*['"]([^'"]+)['"]\s*\)""") to Triple(DiscoveryMethod.DYNAMIC_IMPORT, NodeType.SCRIPT),
        Regex("""require\s*\(\s*['"]([^'"]+)['"]\s*\)""") to Triple(DiscoveryMethod.IMPORT, NodeType.SCRIPT),
        Regex("""fetch\s*\(\s*['"`]([^'"`]+)['"`]""") to Triple(DiscoveryMethod.FETCH, NodeType.API),
        Regex("""\.open\s*\(\s*['"][A-Z]+['"]\s*,\s*['"`]([^'"`]+)['"`]""") to Triple(DiscoveryMethod.XHR, NodeType.API),
        Regex("""new\s+WebSocket\s*\(\s*['"`]([^'"`]+)['"`]""") to Triple(DiscoveryMethod.WEBSOCKET, NodeType.API),
        Regex("""new\s+EventSource\s*\(\s*['"`]([^'"`]+)['"`]""") to Triple(DiscoveryMethod.XHR, NodeType.API),
        Regex("""new\s+Worker\s*\(\s*['"`]([^'"`]+)['"`]""") to Triple(DiscoveryMethod.WORKER, NodeType.WORKER),
        Regex("""new\s+SharedWorker\s*\(\s*['"`]([^'"`]+)['"`]""") to Triple(DiscoveryMethod.SHARED_WORKER, NodeType.WORKER),
        Regex("""serviceWorker\.register\s*\(\s*['"`]([^'"`]+)['"`]""") to Triple(DiscoveryMethod.SERVICE_WORKER, NodeType.SERVICE_WORKER),
        Regex("""\.src\s*=\s*['"`]([^'"`]+\.(?:js|mjs|cjs)[^'"`]*)['"`]""") to Triple(DiscoveryMethod.STATIC_SCRIPT, NodeType.SCRIPT),
        Regex("""navigator\.sendBeacon\s*\(\s*['"`]([^'"`]+)['"`]""") to Triple(DiscoveryMethod.FETCH, NodeType.API)
    ).flatMap { (r, t) -> listOf(Triple(r, t.first, t.second)) }

    private val cssUrl = Regex("""url\(\s*['"]?([^)'"]+)['"]?\s*\)""")
    private val cssImport = Regex("""@import\s+(?:url\()?\s*['"]([^'"]+)['"]""")

    // Spec §15 — secret patterns. Values are redacted everywhere.
    private val secretPatterns = listOf(
        "AWS_ACCESS_KEY" to Regex("""AKIA[0-9A-Z]{16}"""),
        "GOOGLE_API_KEY" to Regex("""AIza[0-9A-Za-z_\-]{35}"""),
        "PRIVATE_KEY" to Regex("""-----BEGIN [A-Z ]*PRIVATE KEY-----"""),
        "GITHUB_TOKEN" to Regex("""ghp_[0-9A-Za-z]{36}"""),
        "STRIPE_KEY" to Regex("""[sr]k_live_[0-9A-Za-z]{16,}"""),
        "JWT" to Regex("""eyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{5,}"""),
        "GENERIC_SECRET" to Regex("""(?:api[_-]?key|secret|token|password)\s*[:=]\s*['"]([A-Za-z0-9_\-./+]{16,})['"]""")
    )

    fun scanJs(source: String): List<Ref> {
        val out = LinkedHashMap<String, Ref>()
        for ((regex, method, hint) in patterns) {
            for (m in regex.findAll(source)) {
                val u = m.groupValues[1]
                if (u.startsWith("data:") || u.startsWith("blob:")) continue
                out.putIfAbsent("$method:$u", Ref(u, method, hint))
            }
        }
        return out.values.toList()
    }

    fun scanCss(source: String): List<Ref> {
        val out = LinkedHashMap<String, Ref>()
        cssUrl.findAll(source).forEach {
            val u = it.groupValues[1]
            if (!u.startsWith("data:")) out.putIfAbsent(u, Ref(u, DiscoveryMethod.STATIC_CSS, NodeType.OTHER))
        }
        cssImport.findAll(source).forEach {
            out.putIfAbsent(it.groupValues[1], Ref(it.groupValues[1], DiscoveryMethod.STATIC_CSS, NodeType.STYLE))
        }
        return out.values.toList()
    }

    fun scanSecrets(source: String): List<SecretHit> =
        secretPatterns.mapNotNull { (kind, r) ->
            r.find(source)?.let { SecretHit(kind, redact(it.value)) }
        }.distinctBy { it.redacted }

    fun redactAll(text: String): String {
        var t = text
        for ((_, r) in secretPatterns) t = t.replace(r, "██REDACTED██")
        return t
    }

    private fun redact(v: String): String =
        if (v.length <= 8) "██REDACTED██" else v.take(4) + "…██REDACTED██…" + v.takeLast(2)

    fun sourceMapComment(source: String): String? =
        Regex("""[#@]\s*sourceMappingURL=([^\s*]+)""").findAll(source).lastOrNull()?.groupValues?.get(1)
}
