package com.extractor.wse.acquire

import android.content.Context
import com.extractor.wse.core.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * Acquisition orchestrator (spec §4, §19, §28):
 * multi-pass convergence, checkpointed resumable crawling, strict scope.
 * UI never owns extraction state — this class does, persisted on disk.
 */
class Orchestrator(private val context: Context) {

    data class Progress(
        val pass: String = "IDLE",
        val discovered: Int = 0,
        val queued: Int = 0,
        val completed: Int = 0,
        val bytes: Long = 0,
        val js: Int = 0, val css: Int = 0, val maps: Int = 0,
        val workers: Int = 0, val routes: Int = 0, val apis: Int = 0,
        val errors: Int = 0, val warnings: Int = 0,
        val running: Boolean = false,
        val done: Boolean = false,
        val snapshotId: String? = null
    )

    val progress = MutableStateFlow(Progress())

    private val errors = mutableListOf<ExtractionError>()
    private val warnings = mutableListOf<String>()
    private val apiInventory = mutableListOf<ApiObservation>()
    private val runtimeTrace = mutableListOf<RuntimeEvent>()
    private val sourceMapReport = mutableListOf<Map<String, String>>()

    lateinit var store: ArtifactStore
    private val graph = ResourceGraph()
    private lateinit var rootDir: File
    private var limits = SecurityGuard.Limits()

    private val pending = ArrayDeque<PendingItem>()
    private val pendingLock = Mutex()
    private val seen = ConcurrentHashMap.newKeySet<String>()
    private val active = AtomicInteger(0)

    private fun checkpointFile() = File(rootDir, "checkpoint.json")

    suspend fun run(target: String, mode: BatteryMode, resume: Boolean): Snapshot {
        currentTarget = target
        val scope = originOf(target)
        rootDir = File(context.filesDir, "extractions/${scope.substringAfter("://").replace(Regex("[^A-Za-z0-9.]"), "_")}")
        rootDir.mkdirs()
        store = ArtifactStore(rootDir)
        limits = limits.copy(maxConcurrency = mode.concurrency)

        errors.clear(); warnings.clear(); apiInventory.clear(); runtimeTrace.clear(); sourceMapReport.clear()
        seen.clear(); pending.clear()

        progress.value = Progress(pass = "PASS 0 — METADATA", running = true)
        SecurityGuard.validate(target)
        val start = System.currentTimeMillis()

        // §28 — resume from last verified checkpoint
        val resumed = resume && checkpointFile().exists() && runCatching {
            val cp = json.decodeFromString<Checkpoint>(checkpointFile().readText())
            if (cp.target == target) {
                pending.addAll(cp.pending); seen.addAll(cp.seen)
                graph.loadFrom(cp.evidence, cp.edges)
                warnings.add("Resumed from checkpoint @ ${cp.savedAt}")
                true
            } else false
        }.getOrDefault(false)

        if (!resumed) {
            pending.add(PendingItem(normalizeUrl(target), null, DiscoveryMethod.HTML.name, 0))
        }

        // ---- iterative passes with convergence (§19) ----
        var lastHash = ""
        var iter = 0
        val maxIters = if (mode == BatteryMode.DEEP) 5 else 2
        val runtime = RuntimeEngine(context)

        while (iter < maxIters) {
            iter++
            when (iter) {
                1 -> progress.update("PASS 1-3 — STATIC + DEPENDENCY + SOURCE-MAP")
                else -> progress.update("PASS 4-7 — RUNTIME + ROUTES + WORKERS (iteration $iter)")
            }

            crawl(scope, start) { url, parent, method, depth ->
                // per-artifact hook: parse content, expand dependencies, chase source maps
            }

            // runtime acquisition (§9) — skipped in pure offline/resume-verified runs
            if (seen.size > 0 && System.currentTimeMillis() - start < limits.maxDurationMs) {
                progress.update("PASS 4-7 — RUNTIME (iteration $iter)")
                val rt = runCatching {
                    runtime.explore(normalizeUrl(target), { SecurityGuard.inScope(it, scope) },
                        limits.maxRoutes, limits.maxRuntimeMs)
                }.getOrNull()
                if (rt != null) {
                    runtimeTrace.addAll(rt.trace)
                    apiInventory.addAll(rt.apiCalls)
                    rt.routes.forEach { r ->
                        if (seen.add(normalizeUrl(r))) {
                            pending.add(PendingItem(normalizeUrl(r), target, DiscoveryMethod.ROUTE.name, 1))
                            graph.addEdge(target, normalizeUrl(r), EdgeType.ROUTES_TO)
                        }
                    }
                    rt.discoveredUrls.forEach { (u, m) ->
                        resolveUrl(target, u)?.let { abs ->
                            if (SecurityGuard.inScope(abs, scope) && seen.add(abs))
                                pending.add(PendingItem(abs, target, m.name, 2))
                        }
                    }
                    // re-crawl what runtime discovered
                    crawl(scope, start) { _, _, _, _ -> }
                }
            }

            // convergence check (§19): all graphs must stabilize
            val h = graph.stableHash() + ":" + apiInventory.size + ":" + runtimeTrace.size
            if (h == lastHash) break
            lastHash = h
        }

        // ---- PASS 8 — integrity verification (§22) ----
        progress.update("PASS 8 — INTEGRITY")
        var verified = 0; var corrupt = 0
        for ((url, hash) in store.urlToHash) {
            val bytes = store.bytes(hash) ?: continue
            if (sha256Hex(bytes) == hash) verified++ else {
                corrupt++
                errors.add(ExtractionError(ErrKind.FAILED.name, "INTEGRITY", url, "hash mismatch"))
            }
        }
        if (corrupt > 0) warnings.add("INTEGRITY: $corrupt artifact(s) failed verification")

        // ---- completeness (§21) — never claim 100% source ----
        val evidence = graph.nodes.values.toList()
        fun cov(f: (EvidenceRecord) -> Boolean): Double {
            val all = evidence.filter(f)
            if (all.isEmpty()) return 100.0
            val ok = all.count { it.sha256.isNotEmpty() }
            return ok * 100.0 / all.size
        }
        val totalDiscovered = evidence.size
        val totalAcquired = evidence.count { it.sha256.isNotEmpty() }
        val overall = if (totalDiscovered == 0) 0.0 else totalAcquired * 100.0 / totalDiscovered
        val completeness = mapOf(
            "OVERALL" to overall,
            "HTML" to cov { it.nodeType == NodeType.DOCUMENT.name },
            "STATIC" to cov { it.runtimeStatus == "STATIC" },
            "JAVASCRIPT" to cov { it.nodeType == NodeType.SCRIPT.name },
            "CSS" to cov { it.nodeType == NodeType.STYLE.name },
            "RUNTIME" to cov { it.runtimeStatus == "RUNTIME" },
            "SOURCE_MAP_RECOVERY" to run {
                val scripts = evidence.count { it.nodeType == NodeType.SCRIPT.name }
                val recovered = evidence.count { it.sourceClassification == Classification.SOURCE_MAP_CONFIRMED.name }
                if (scripts == 0) 0.0 else recovered * 100.0 / scripts
            },
            "ROUTES" to cov { it.discoveryMethod == DiscoveryMethod.ROUTE.name },
            "WORKERS" to cov { it.nodeType == NodeType.WORKER.name || it.nodeType == NodeType.SERVICE_WORKER.name }
        )

        val backendVisibility = when {
            apiInventory.isEmpty() -> "BACKEND VISIBILITY: inaccessible (no API observations)"
            apiInventory.any { it.status in 200..299 } -> "BACKEND VISIBILITY: partially observable (interface only — no backend source bytes acquired)"
            else -> "BACKEND VISIBILITY: observable metadata only"
        }

        val snapshot = Snapshot(
            snapshotId = "snap-${System.currentTimeMillis()}",
            targetUrl = target,
            finalUrl = evidence.firstOrNull { it.resourceId == normalizeUrl(target) }?.finalUrl ?: target,
            timestamp = System.currentTimeMillis(),
            scope = scope,
            graphHash = graph.stableHash(),
            artifacts = store.urlToHash.toMap(),
            evidence = evidence,
            edges = graph.edges.toList(),
            apiInventory = apiInventory.toList(),
            runtimeTrace = runtimeTrace.toList(),
            frameworks = FrameworkDetector.detect(evidence, store),
            completeness = completeness,
            completenessStatement = "%.1f%% of discovered accessible resources acquired (%d/%d). Public source coverage != deployed coverage != backend visibility."
                .format(overall, totalAcquired, totalDiscovered),
            backendVisibility = backendVisibility,
            errors = errors.toList(),
            warnings = warnings.toList()
        )

        File(rootDir, "${snapshot.snapshotId}.json").writeText(json.encodeToString(snapshot))
        store.persist()
        checkpointFile().delete() // completed cleanly

        progress.value = progress.value.copy(
            pass = "DONE", running = false, done = true, snapshotId = snapshot.snapshotId
        )
        return snapshot
    }

    /** Bounded-concurrency crawl loop; persists checkpoint after each artifact. */
    private suspend fun crawl(
        scope: String,
        startTime: Long,
        onArtifact: (String, String?, String, Int) -> Unit
    ) = coroutineScope {
        val engine = StaticEngine(store, limits)
        val sm = SourceMapEngine(store)
        val workers = (1..limits.maxConcurrency).map {
            launch(Dispatchers.IO) {
                while (isActive) {
                    if (System.currentTimeMillis() - startTime > limits.maxDurationMs) break
                    if (seen.size >= limits.maxUrls) break
                    val item = pendingLock.withLock { if (pending.isEmpty()) null else pending.removeFirst() }
                    if (item == null) { if (active.get() == 0) break else { delay(80); continue } }
                    active.incrementAndGet()
                    try {
                        processItem(item, engine, sm, scope)
                        onArtifact(item.url, item.parent, item.method, item.depth)
                    } finally {
                        active.decrementAndGet()
                        refreshCounters()
                        saveCheckpoint()
                    }
                }
            }
        }
        workers.joinAll()
    }

    private suspend fun processItem(item: PendingItem, engine: StaticEngine, sm: SourceMapEngine, scope: String) {
        if (!SecurityGuard.inScope(item.url, scope)) {
            errors.add(ExtractionError(ErrKind.CROSS_ORIGIN_LIMIT.name, "SCOPE", item.url, "out of scope"))
            return
        }
        when (val out = engine.fetch(item)) {
            is StaticEngine.FetchOutcome.Failed -> {
                graph.addNode(out.record)
                out.record.discoveryParent?.let { graph.addEdge(it, item.url, EdgeType.DISCOVERED_FROM) }
                errors.add(out.error)
            }
            is StaticEngine.FetchOutcome.Ok -> {
                val rec = out.record
                graph.addNode(rec)
                rec.discoveryParent?.let { graph.addEdge(it, rec.resourceId, EdgeType.DISCOVERED_FROM) }
                SecurityGuard.checkProjectBudget(store.totalBytes(), limits)

                // dependency expansion (§5, §7)
                if (item.depth < limits.maxDepth && StaticEngine.isText(rec.mimeType)) {
                    val text = String(out.bytes, Charsets.UTF_8)
                    val refs: List<Triple<String, DiscoveryMethod, NodeType>> = when (rec.nodeType) {
                        NodeType.DOCUMENT.name, NodeType.FRAME.name ->
                            HtmlParser.extract(text).map { Triple(it.url, it.method, it.hint) }
                        NodeType.SCRIPT.name, NodeType.WORKER.name, NodeType.SERVICE_WORKER.name ->
                            JsAnalyzer.scanJs(text).map { Triple(it.url, it.method, it.hint) }
                        NodeType.STYLE.name ->
                            JsAnalyzer.scanCss(text).map { Triple(it.url, it.method, it.hint) }
                        else -> emptyList()
                    }
                    rec.parserStatus = "PARSED"
                    for ((raw, method, hint) in refs) {
                        val abs = resolveUrl(rec.finalUrl.ifEmpty { item.url }, raw) ?: continue
                        if (!SecurityGuard.inScope(abs, scope)) continue
                        graph.addEdge(rec.resourceId, abs, when (method) {
                            DiscoveryMethod.IMPORT, DiscoveryMethod.DYNAMIC_IMPORT, DiscoveryMethod.IMPORT_MAP -> EdgeType.IMPORTS
                            DiscoveryMethod.FETCH, DiscoveryMethod.XHR, DiscoveryMethod.WEBSOCKET -> EdgeType.CALLS
                            DiscoveryMethod.WORKER, DiscoveryMethod.SHARED_WORKER, DiscoveryMethod.SERVICE_WORKER -> EdgeType.CREATES
                            else -> EdgeType.LOADS
                        })
                        if (hint == NodeType.API) {
                            apiInventory.add(ApiObservation("GET", abs, originOf(abs), callerResource = rec.resourceId))
                        } else if (method != DiscoveryMethod.WEBSOCKET && !abs.startsWith("ws")) {
                            if (seen.add(abs)) pendingLock.withLock {
                                pending.add(PendingItem(abs, rec.resourceId, method.name, item.depth + 1))
                            }
                        }
                    }

                    // §8 — source maps for JS/CSS
                    if (rec.nodeType == NodeType.SCRIPT.name || rec.nodeType == NodeType.STYLE.name) {
                        processSourceMaps(rec, text, out.sourceMapHeader, engine, sm)
                    }
                }
                if (rec.nodeType == NodeType.SOURCE_MAP.name) {
                    val result = sm.process(rec.finalUrl.ifEmpty { item.url }, out.bytes, rec.discoveryParent ?: item.url)
                    integrateSourceMap(result, rec, sm)
                }
            }
        }
    }

    private suspend fun processSourceMaps(
        rec: EvidenceRecord, text: String, header: String?,
        engine: StaticEngine, sm: SourceMapEngine
    ) {
        val candidates = sm.findMapReference(rec.finalUrl.ifEmpty { rec.resourceId }, text, header)
        for (mapUrl in candidates) {
            if (mapUrl.startsWith("inline:")) {
                val hash = mapUrl.removePrefix("inline:")
                val bytes = store.bytes(hash) ?: continue
                rec.sourceMapStatus = "FOUND"
                integrateSourceMap(sm.process("inline-map-of:${rec.resourceId}", bytes, rec.resourceId), rec, sm)
                return
            }
            if (!SecurityGuard.inScope(mapUrl, rec.origin) && mapUrl != candidates.first()) continue
            val outcome = engine.fetch(PendingItem(mapUrl, rec.resourceId, DiscoveryMethod.SOURCE_MAP.name, 0))
            if (outcome is StaticEngine.FetchOutcome.Ok) {
                rec.sourceMapStatus = "FOUND"
                graph.addNode(outcome.record)
                graph.addEdge(rec.resourceId, outcome.record.resourceId, EdgeType.MAPS_TO)
                integrateSourceMap(sm.process(outcome.record.finalUrl, outcome.bytes, rec.resourceId), outcome.record, sm)
                return
            }
        }
        rec.sourceMapStatus = "NONE"
        rec.warnings.add("DEPLOYED BUNDLE ONLY — no accessible source map")
    }

    private suspend fun integrateSourceMap(result: SourceMapEngine.MapResult, mapRec: EvidenceRecord, sm: SourceMapEngine) {
        if (!result.valid) {
            mapRec.sourceMapStatus = "FAILED"
            errors.add(ExtractionError(ErrKind.SOURCE_MAP_ERROR.name, "SOURCE_MAP", result.mapUrl, result.error ?: "invalid"))
            return
        }
        mapRec.sourceMapStatus = "VALIDATED"
        sourceMapReport.add(mapOf(
            "map" to result.mapUrl,
            "sources" to result.sources.size.toString(),
            "recovered" to result.recovered.size.toString()
        ))
        for (src in result.recovered) {
            graph.addNode(src)
            graph.addEdge(mapRec.resourceId, src.resourceId, EdgeType.MAPS_TO)
        }
    }

    private var lastCheckpoint = 0L
    private var currentTarget = ""
    private fun saveCheckpoint() {
        val now = System.currentTimeMillis()
        if (now - lastCheckpoint < 3000) return
        lastCheckpoint = now
        runCatching {
            val cp = Checkpoint(
                target = currentTarget,
                pending = synchronized(pending) { pending.toList() },
                seen = seen.toSet(),
                evidence = graph.nodes.values.toList(),
                edges = graph.edges.toList()
            )
            checkpointFile().writeText(json.encodeToString(cp))
        }
    }

    private fun MutableStateFlow<Progress>.update(pass: String) { value = value.copy(pass = pass) }

    fun refreshCounters() {
        val e = graph.nodes.values
        progress.value = progress.value.copy(
            discovered = seen.size + e.size,
            queued = pending.size,
            completed = e.count { it.sha256.isNotEmpty() },
            bytes = store.totalBytes(),
            js = e.count { it.nodeType == NodeType.SCRIPT.name },
            css = e.count { it.nodeType == NodeType.STYLE.name },
            maps = e.count { it.nodeType == NodeType.SOURCE_MAP.name },
            workers = e.count { it.nodeType == NodeType.WORKER.name || it.nodeType == NodeType.SERVICE_WORKER.name },
            routes = e.count { it.discoveryMethod == DiscoveryMethod.ROUTE.name },
            apis = apiInventory.size,
            errors = errors.size,
            warnings = warnings.size + e.sumOf { it.warnings.size }
        )
    }

    companion object {
        fun listSnapshots(context: Context): List<Pair<File, Snapshot>> =
            File(context.filesDir, "extractions").walkTopDown()
                .filter { it.name.startsWith("snap-") && it.extension == "json" }
                .mapNotNull { f -> runCatching { f to json.decodeFromString<Snapshot>(f.readText()) }.getOrNull() }
                .sortedByDescending { it.second.timestamp }
                .toList()

        fun loadSnapshot(context: Context, id: String): Snapshot? =
            listSnapshots(context).firstOrNull { it.second.snapshotId == id }?.second
    }
}
