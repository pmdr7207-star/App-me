package com.extractor.wse.acquire

import android.annotation.SuppressLint
import android.content.Context
import android.webkit.*
import com.extractor.wse.core.*
import kotlinx.coroutines.*
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Browser runtime engine (spec §9, §10): isolated WebView session capturing
 * DOM, network, console, JS errors, workers, service workers, routes and
 * dynamic imports into a reproducible structured trace.
 * Only safe, non-destructive exploration is performed.
 */
class RuntimeEngine(private val context: Context) {

    data class RuntimeResult(
        val trace: List<RuntimeEvent>,
        val discoveredUrls: List<Pair<String, DiscoveryMethod>>,
        val routes: List<String>,
        val apiCalls: List<ApiObservation>,
        val documentHtml: String?
    )

    private val events = CopyOnWriteArrayList<RuntimeEvent>()
    private val discovered = CopyOnWriteArrayList<Pair<String, DiscoveryMethod>>()
    private val routes = CopyOnWriteArrayList<String>()
    private val apis = CopyOnWriteArrayList<ApiObservation>()

    inner class JsBridge {
        @android.webkit.JavascriptInterface
        fun onEvent(payload: String) {
            runCatching {
                val o = json.parseToJsonElement(payload).let { it as kotlinx.serialization.json.JsonObject }
                val type = o["type"]?.toString()?.trim('"') ?: return@runCatching
                val url = o["url"]?.toString()?.trim('"') ?: ""
                val detail = o["detail"]?.toString()?.trim('"') ?: ""
                events.add(RuntimeEvent(type, url, detail))
                when (type) {
                    "fetch" -> { discovered.add(url to DiscoveryMethod.FETCH); apis.add(ApiObservation("GET", url, originOf(url), callerResource = "runtime")) }
                    "xhr" -> { discovered.add(url to DiscoveryMethod.XHR); apis.add(ApiObservation(detail.ifEmpty { "GET" }, url, originOf(url), callerResource = "runtime")) }
                    "websocket" -> discovered.add(url to DiscoveryMethod.WEBSOCKET)
                    "worker" -> discovered.add(url to DiscoveryMethod.WORKER)
                    "sw" -> discovered.add(url to DiscoveryMethod.SERVICE_WORKER)
                    "route" -> if (url.isNotEmpty()) routes.add(url)
                    "dynamic-import" -> discovered.add(url to DiscoveryMethod.DYNAMIC_IMPORT)
                }
            }
        }
    }

    private val hookJs = """
        (function(){ if(window.__wse) return; window.__wse=1;
        function send(t,u,d){ try{ WSE.onEvent(JSON.stringify({type:t,url:u?(''+u):location.href,detail:d?(''+d):''})); }catch(e){} }
        try { var of=window.fetch; window.fetch=function(){ var a=arguments[0]; send('fetch',(a&&a.url)||a); return of.apply(this,arguments); }; } catch(e){}
        try { var oo=XMLHttpRequest.prototype.open; XMLHttpRequest.prototype.open=function(m,u){ send('xhr',u,m); return oo.apply(this,arguments); }; } catch(e){}
        try { var OW=window.Worker; window.Worker=function(u,o){ send('worker',u); return new OW(u,o); }; } catch(e){}
        try { var OSW=window.SharedWorker; window.SharedWorker=function(u,o){ send('worker',u); return new OSW(u,o); }; } catch(e){}
        try { if(navigator.serviceWorker){ var or=navigator.serviceWorker.register.bind(navigator.serviceWorker);
              navigator.serviceWorker.register=function(u,o){ send('sw',u); return or(u,o); }; } } catch(e){}
        try { var op=history.pushState; history.pushState=function(){ send('route',arguments[2]||location.href); return op.apply(this,arguments); };
              window.addEventListener('popstate',function(){ send('route',location.href); }); } catch(e){}
        try { var ce=console.error.bind(console), cw=console.warn.bind(console);
              console.error=function(){ send('console',location.href,[].join.call(arguments,' ')); ce.apply(null,arguments); };
              console.warn=function(){ send('console',location.href,[].join.call(arguments,' ')); cw.apply(null,arguments); }; } catch(e){}
        window.addEventListener('error',function(e){ send('jserror',e.filename||location.href,e.message); },true);
        })();
    """.trimIndent()

    private val collectLinksJs = """
        (function(){ var out=[]; var a=document.querySelectorAll('a[href]');
        for(var i=0;i<a.length;i++){ out.push(a[i].href); }
        return JSON.stringify(out.slice(0,300)); })();
    """.trimIndent()

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface")
    suspend fun explore(
        startUrl: String,
        inScope: (String) -> Boolean,
        maxRoutes: Int,
        budgetMs: Long
    ): RuntimeResult {
        events.clear(); discovered.clear(); routes.clear(); apis.clear()
        return withContext(Dispatchers.Main) {
            val wv = WebView(context)
            try {
                wv.settings.javaScriptEnabled = true
                wv.settings.domStorageEnabled = true
                wv.settings.cacheMode = WebSettings.LOAD_DEFAULT
                wv.addJavascriptInterface(JsBridge(), "WSE")

                var pageFinished: CompletableDeferred<Boolean>? = null
                var html: String? = null

                wv.webViewClient = object : WebViewClient() {
                    override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                        events.add(RuntimeEvent("navigation", url))
                        view.evaluateJavascript(hookJs, null)
                    }

                    override fun onPageFinished(view: WebView, url: String) {
                        view.evaluateJavascript(hookJs, null)
                        events.add(RuntimeEvent("loaded", url))
                        pageFinished?.complete(true)
                    }

                    override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                        val u = request.url?.toString() ?: return null
                        events.add(RuntimeEvent("network", u, request.method ?: "GET"))
                        discovered.add(u to DiscoveryMethod.NETWORK)
                        if (request.isForMainFrame) routes.add(u)
                        return null // observe only — never block
                    }

                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                        val u = request.url?.toString() ?: return true
                        return if (inScope(u)) { routes.add(u); false } else {
                            events.add(RuntimeEvent("blocked-out-of-scope", u)); true
                        }
                    }

                    override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                        events.add(RuntimeEvent("resource-error", request.url?.toString() ?: "", error.description?.toString() ?: ""))
                    }
                }

                suspend fun loadAndWait(url: String, timeoutMs: Long): Boolean {
                    pageFinished = CompletableDeferred()
                    wv.loadUrl(url)
                    return try { withTimeout(timeoutMs) { pageFinished!!.await() } }
                    catch (_: TimeoutCancellationException) { events.add(RuntimeEvent("timeout", url)); false }
                }

                val deadline = System.currentTimeMillis() + budgetMs
                if (loadAndWait(startUrl, 30_000)) {
                    // collect in-page routes
                    val linksJson = suspendCancellableCoroutine<String?> { cont ->
                        wv.evaluateJavascript(collectLinksJs) { v -> cont.resume(v, null) }
                    }
                    val links = runCatching {
                        json.decodeFromString<List<String>>(linksJson?.removeSurrounding("\"")?.replace("\\\"", "\"") ?: "[]")
                    }.getOrDefault(emptyList())

                    // PASS 5 — safe route exploration (BFS, in-scope only, depth 1)
                    val visited = mutableSetOf(startUrl)
                    val queue = ArrayDeque(links.mapNotNull { resolveUrl(startUrl, it) }.filter { inScope(it) && it !in visited })
                    while (queue.isNotEmpty() && visited.size < maxRoutes && System.currentTimeMillis() < deadline) {
                        val next = queue.removeFirst()
                        if (!visited.add(next)) continue
                        events.add(RuntimeEvent("route-explore", next))
                        if (!loadAndWait(next, 20_000)) continue
                        val more = suspendCancellableCoroutine<String?> { cont ->
                            wv.evaluateJavascript(collectLinksJs) { v -> cont.resume(v, null) }
                        }
                        runCatching {
                            json.decodeFromString<List<String>>(more?.removeSurrounding("\"")?.replace("\\\"", "\"") ?: "[]")
                        }.getOrDefault(emptyList()).forEach {
                            resolveUrl(next, it)?.let { r -> if (inScope(r) && r !in visited) queue.add(r) }
                        }
                    }
                    // final DOM snapshot
                    html = suspendCancellableCoroutine { cont ->
                        wv.evaluateJavascript("document.documentElement.outerHTML") { v -> cont.resume(v, null) }
                    }
                }
                RuntimeResult(events.toList(), discovered.toList(), routes.distinct(), apis.toList(), html)
            } finally {
                runCatching { wv.stopLoading(); wv.destroy() }
            }
        }
    }
}
