package com.extractor.wse.acquire

import com.extractor.wse.core.*
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonPrimitive

/**
 * Source-map engine (spec §8): resolves SourceMap header / X-SourceMap /
 * sourceMappingURL comment / companion .map. Maintains DEPLOYED vs
 * AUTHORED artifacts and never overwrites deployed bytes.
 */
class SourceMapEngine(private val store: ArtifactStore) {

    data class MapResult(
        val mapUrl: String,
        val mapRecord: EvidenceRecord?,
        val sources: List<String>,
        val recovered: List<EvidenceRecord>,
        val valid: Boolean,
        val error: String? = null
    )

    fun findMapReference(jsUrl: String, source: String, header: String?): List<String> {
        val out = LinkedHashSet<String>()
        header?.let { resolveUrl(jsUrl, it)?.let(out::add) }
        JsAnalyzer.sourceMapComment(source)?.let { ref ->
            if (ref.startsWith("data:")) {
                // inline base64 map — decode in place
                runCatching {
                    val b64 = ref.substringAfter("base64,")
                    val bytes = java.util.Base64.getDecoder().decode(b64)
                    out.add("inline:" + store.put("$jsUrl#inline-map", bytes))
                }
            } else resolveUrl(jsUrl, ref)?.let(out::add)
        }
        resolveUrl(jsUrl, "$jsUrl.map")?.let(out::add) // companion candidate
        return out.toList()
    }

    /** Parse a validated source map; returns recovered authored sources with provenance. */
    fun process(mapUrl: String, mapBytes: ByteArray, ownerJsUrl: String): MapResult {
        val now = System.currentTimeMillis()
        return try {
            val obj = json.parseToJsonElement(String(mapBytes, Charsets.UTF_8)) as JsonObject
            val version = obj["version"]?.jsonPrimitive?.content?.toIntOrNull() ?: 0
            if (version != 3) return MapResult(mapUrl, null, emptyList(), emptyList(), false, "unsupported version $version")

            val sourceRoot = obj["sourceRoot"]?.jsonPrimitive?.content ?: ""
            val sources = obj["sources"]?.jsonArray?.map { it.jsonPrimitive.content } ?: emptyList()
            val contents = obj["sourcesContent"]?.jsonArray?.map {
                runCatching { it.jsonPrimitive.content }.getOrNull()
            }
            val mappings = obj["mappings"]?.jsonPrimitive?.content ?: ""
            val mappingsOk = mappings.isEmpty() || Vlq.validate(mappings)

            val recovered = mutableListOf<EvidenceRecord>()
            sources.forEachIndexed { i, srcPath ->
                val content = contents?.getOrNull(i) ?: return@forEachIndexed
                val cleanPath = cleanSourcePath(sourceRoot, srcPath)
                val rid = "sourcemap://$mapUrl!$cleanPath"
                val hash = store.put(rid, content.toByteArray(Charsets.UTF_8))
                val rec = EvidenceRecord(
                    resourceId = rid,
                    sourceUrl = rid,
                    finalUrl = rid,
                    origin = originOf(ownerJsUrl),
                    discoveryMethod = DiscoveryMethod.SOURCE_MAP.name,
                    discoveryParent = ownerJsUrl,
                    sha256 = hash,
                    contentLength = content.length.toLong(),
                    acquiredAt = now, firstSeenAt = now, lastSeenAt = now,
                    mimeType = StaticEngine.guessMime(cleanPath),
                    sourceClassification = Classification.SOURCE_MAP_CONFIRMED.name,
                    authoredStatus = "AUTHORED",
                    runtimeStatus = "STATIC",
                    parserStatus = "PARSED",
                    sourceMapStatus = "VALIDATED",
                    confidence = Confidence.SOURCE_MAP_CONFIRMED.name,
                    nodeType = when (StaticEngine.guessMime(cleanPath)) {
                        "text/javascript" -> NodeType.SCRIPT.name
                        "text/css" -> NodeType.STYLE.name
                        else -> NodeType.OTHER.name
                    }
                )
                if (!mappingsOk) rec.warnings.add("mappings decode unverified")
                recovered.add(rec)
            }
            MapResult(mapUrl, null, sources.map { cleanSourcePath(sourceRoot, it) }, recovered, true)
        } catch (e: Exception) {
            MapResult(mapUrl, null, emptyList(), emptyList(), false, "SOURCE_MAP_ERROR: ${e.message}")
        }
    }

    /** webpack://app/./src/x.ts, ../src/x.ts -> src/x.ts (never invent — only sanitize). */
    fun cleanSourcePath(root: String, src: String): String {
        var p = if (src.contains("://")) src.substringAfter("://").substringAfter('/', "") else src
        if (p.isEmpty()) p = src.substringAfterLast('/')
        val parts = mutableListOf<String>()
        for (seg in (if (root.isNotEmpty() && !p.startsWith("/")) "$root/$p" else p).split('/')) {
            when (seg) {
                "", "." -> {}
                ".." -> if (parts.isNotEmpty()) parts.removeAt(parts.size - 1)
                else -> parts.add(seg)
            }
        }
        return parts.joinToString("/").ifEmpty { "unknown/${src.substringAfterLast('/')}" }
    }
}

/** Base64 VLQ decoder for validating mappings (spec §8 — validate the map). */
object Vlq {
    private const val CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

    fun decodeSegment(seg: String): IntArray {
        val out = ArrayList<Int>()
        var value = 0; var shift = 0
        for (c in seg) {
            val digit = CHARS.indexOf(c)
            if (digit < 0) throw IllegalArgumentException("bad VLQ char")
            val cont = digit and 32
            value += (digit and 31) shl shift
            if (cont != 0) { shift += 5 } else {
                val neg = value and 1
                out.add(if (neg != 0) -(value shr 1) else value shr 1)
                value = 0; shift = 0
            }
        }
        return out.toIntArray()
    }

    fun validate(mappings: String): Boolean = runCatching {
        var checked = 0
        for (line in mappings.split(';')) {
            if (line.isEmpty()) continue
            for (seg in line.split(',')) if (seg.isNotEmpty()) decodeSegment(seg)
            if (++checked > 50) break // sample first 50 lines — enough to validate structure
        }
    }.isSuccess
}
