package com.extractor.wse.acquire

import com.extractor.wse.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/**
 * Static acquisition engine (spec §5): bounded fetch with manual redirect
 * handling, SSRF guard per hop, streaming size caps, content classification.
 */
class StaticEngine(
    private val store: ArtifactStore,
    private val limits: SecurityGuard.Limits
) {
    private val client = OkHttpClient.Builder()
        .followRedirects(false)
        .followSslRedirects(false)
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(40, TimeUnit.SECONDS)
        .build()

    sealed class FetchOutcome {
        data class Ok(val record: EvidenceRecord, val bytes: ByteArray, val sourceMapHeader: String?) : FetchOutcome()
        data class Failed(val record: EvidenceRecord, val error: ExtractionError) : FetchOutcome()
    }

    suspend fun fetch(item: PendingItem): FetchOutcome = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val rec = EvidenceRecord(
            resourceId = item.url,
            sourceUrl = item.url,
            origin = originOf(item.url),
            discoveryMethod = item.method,
            discoveryParent = item.parent,
            firstSeenAt = now,
            lastSeenAt = now
        )
        var current = item.url
        var redirects = 0
        try {
            while (true) {
                SecurityGuard.validate(current)
                val req = Request.Builder().url(current)
                    .header("User-Agent", "WSE-Extractor/2.0 (evidence-driven acquisition)")
                    .header("Accept", "*/*")
                    .build()
                val hop = client.newCall(req).execute().use { resp ->
                    val code = resp.code
                    if (code in 300..399) {
                        val loc = resp.header("Location")
                        return@use Hop.Redirect(loc)
                    }
                    val mapHeader = resp.header("SourceMap") ?: resp.header("X-SourceMap")
                    rec.httpStatus = code
                    rec.finalUrl = current
                    rec.etag = resp.header("ETag")
                    rec.lastModified = resp.header("Last-Modified")
                    val ctype = resp.header("Content-Type").orEmpty()
                    rec.mimeType = ctype.substringBefore(';').trim().lowercase()
                        .ifEmpty { guessMime(current) }
                    rec.encoding = ctype.substringAfter("charset=", "").trim()
                    if (code in 200..299) {
                        val body = resp.body ?: return@use Hop.Error(ErrKind.FAILED, code, "empty body")
                        val declared = body.contentLength()
                        if (declared > limits.maxResponseSize)
                            return@use Hop.Error(ErrKind.BLOCKED, code, "response over maxResponseSize")
                        val bytes = body.bytes() // capped: OkHttp throws on oversize via declared check
                        if (bytes.size > limits.maxResponseSize)
                            return@use Hop.Error(ErrKind.BLOCKED, code, "response over maxResponseSize")
                        Hop.Data(bytes, mapHeader)
                    } else {
                        Hop.Error(
                            when (code) {
                                401, 403 -> ErrKind.AUTH_REQUIRED
                                404 -> ErrKind.NOT_FOUND
                                in 500..599 -> ErrKind.SERVER_ERROR
                                else -> ErrKind.FAILED
                            }, code, "HTTP $code"
                        )
                    }
                }
                when (hop) {
                    is Hop.Redirect -> {
                        val loc = hop.location ?: return@withContext fail(rec, ErrKind.FAILED, 0, "redirect without Location")
                        redirects++
                        if (redirects > limits.maxRedirects)
                            return@withContext fail(rec, ErrKind.BLOCKED, 0, "too many redirects")
                        val next = resolveUrl(current, loc)
                            ?: return@withContext fail(rec, ErrKind.FAILED, 0, "bad redirect target")
                        rec.warnings.add("REDIRECT $current -> $next")
                        current = next
                    }
                    is Hop.Error -> return@withContext fail(rec, hop.kind, hop.status, hop.message)
                    is Hop.Data -> {
                        val normalized = normalizeUrl(current)
                        rec.finalUrl = normalized
                        // resume optimization (spec §28): unchanged hash -> skip re-processing
                        val hash = store.put(normalized, hop.bytes)
                        rec.sha256 = hash
                        rec.contentLength = hop.bytes.size.toLong()
                        rec.acquiredAt = System.currentTimeMillis()
                        classify(rec, hop.bytes)
                        detectSecrets(rec, hop.bytes)
                        return@withContext FetchOutcome.Ok(rec, hop.bytes, hop.sourceMapHeader)
                    }
                }
            }
        } catch (e: SecurityGuard.BlockedTarget) {
            fail(rec, ErrKind.BLOCKED, 0, e.message ?: "blocked")
        } catch (e: java.net.SocketTimeoutException) {
            fail(rec, ErrKind.TIMEOUT, 0, e.message ?: "timeout")
        } catch (e: Exception) {
            fail(rec, ErrKind.FAILED, 0, "${e.javaClass.simpleName}: ${e.message}")
        }
    }

    private fun fail(rec: EvidenceRecord, kind: ErrKind, status: Int, msg: String): FetchOutcome.Failed {
        rec.sourceClassification = Classification.ERROR.name
        rec.errors.add("$kind: $msg")
        return FetchOutcome.Failed(
            rec, ExtractionError(kind.name, "FETCH", rec.resourceId, msg, status)
        )
    }

    private fun detectSecrets(rec: EvidenceRecord, bytes: ByteArray) {
        if (!isText(rec.mimeType)) return
        val hits = JsAnalyzer.scanSecrets(String(bytes, Charsets.UTF_8))
        if (hits.isNotEmpty()) {
            rec.secretDetected = true
            rec.warnings.add("SECRET_DETECTED: " + hits.joinToString { it.kind })
        }
    }

    companion object {
        private sealed class Hop {
            data class Redirect(val location: String?) : Hop()
            data class Data(val bytes: ByteArray, val sourceMapHeader: String?) : Hop()
            data class Error(val kind: ErrKind, val status: Int, val message: String) : Hop()
        }

        fun isText(mime: String): Boolean =
            mime.startsWith("text/") || mime.contains("json") || mime.contains("javascript")
                    || mime.contains("xml") || mime.contains("svg") || mime.isEmpty()

        fun guessMime(url: String): String = when (url.substringAfterLast('.').substringBefore('?').lowercase()) {
            "html", "htm" -> "text/html"
            "js", "mjs", "cjs" -> "text/javascript"
            "css" -> "text/css"
            "json", "map" -> "application/json"
            "wasm" -> "application/wasm"
            "png" -> "image/png"; "jpg", "jpeg" -> "image/jpeg"; "gif" -> "image/gif"
            "svg" -> "image/svg+xml"; "webp" -> "image/webp"; "ico" -> "image/x-icon"
            "woff" -> "font/woff"; "woff2" -> "font/woff2"; "ttf" -> "font/ttf"; "otf" -> "font/otf"
            "mp4" -> "video/mp4"; "webm" -> "video/webm"; "mp3" -> "audio/mpeg"; "wav" -> "audio/wav"
            "xml" -> "application/xml"; "pdf" -> "application/pdf"
            else -> "application/octet-stream"
        }

        fun classify(rec: EvidenceRecord, bytes: ByteArray) {
            val m = rec.mimeType
            rec.nodeType = when {
                m.contains("html") -> NodeType.DOCUMENT
                m.contains("javascript") || m == "text/js" -> NodeType.SCRIPT
                m.contains("css") -> NodeType.STYLE
                m.startsWith("image/") -> NodeType.IMAGE
                m.startsWith("font/") || m.contains("font") -> NodeType.FONT
                m.startsWith("video/") || m.startsWith("audio/") -> NodeType.MEDIA
                m.contains("json") -> if (rec.resourceId.endsWith(".map")) NodeType.SOURCE_MAP else NodeType.JSON
                m.contains("wasm") -> NodeType.WASM
                else -> NodeType.OTHER
            }.name
            if (rec.resourceId.endsWith(".map")) rec.nodeType = NodeType.SOURCE_MAP.name
            if (rec.discoveryMethod == DiscoveryMethod.WORKER.name) rec.nodeType = NodeType.WORKER.name
            if (rec.discoveryMethod == DiscoveryMethod.SERVICE_WORKER.name) rec.nodeType = NodeType.SERVICE_WORKER.name

            // classification (spec §16): never pretend bundle = original source
            rec.sourceClassification = when {
                rec.nodeType == NodeType.SOURCE_MAP.name -> Classification.GENERATED_RESOURCE.name
                rec.nodeType == NodeType.SCRIPT.name || rec.nodeType == NodeType.STYLE.name -> {
                    val head = String(bytes.take(4096).toByteArray(), Charsets.UTF_8)
                    val looksBundled = head.contains("webpack") || head.contains("__webpack_require__")
                            || head.contains("parcelRequire") || bytes.size > 200_000
                    when {
                        looksBundled -> Classification.BUNDLED_SOURCE.name
                        else -> Classification.DEPLOYED_SOURCE.name
                    }
                }
                rec.nodeType == NodeType.DOCUMENT.name -> Classification.DEPLOYED_SOURCE.name
                rec.nodeType == NodeType.JSON.name -> Classification.GENERATED_RESOURCE.name
                m.startsWith("image/") || m.startsWith("font/") || m.startsWith("video/") || m.startsWith("audio/")
                        || m.contains("wasm") || m == "application/octet-stream" -> Classification.BINARY_ASSET.name
                else -> Classification.DEPLOYED_SOURCE.name
            }
            rec.authoredStatus = if (rec.nodeType == NodeType.SCRIPT.name || rec.nodeType == NodeType.STYLE.name)
                "DEPLOYED" else "UNKNOWN"
            rec.confidence = Confidence.EXACT.name // bytes acquired = exact for deployed artifact
            rec.runtimeStatus = "STATIC"
        }
    }
}
