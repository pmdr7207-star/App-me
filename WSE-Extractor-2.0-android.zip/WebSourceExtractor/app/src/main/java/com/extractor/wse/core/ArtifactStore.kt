package com.extractor.wse.core

import kotlinx.serialization.json.Json
import java.io.File
import java.io.InputStream
import java.security.MessageDigest

/**
 * Content-addressed storage (spec §3): bytes are stored by SHA-256,
 * never by URL. Multiple URLs sharing identical bytes map to one artifact.
 */
class ArtifactStore(root: File) {

    val dir = File(root, "artifacts").apply { mkdirs() }
    private val mapFile = File(root, "url-map.json")

    /** normalizedUrl -> sha256 */
    val urlToHash: MutableMap<String, String> = mutableMapOf()

    /** sha256 -> urls referencing it */
    val hashToUrls: MutableMap<String, MutableSet<String>> = mutableMapOf()

    init {
        if (mapFile.exists()) runCatching {
            urlToHash.putAll(Json.decodeFromString<Map<String, String>>(mapFile.readText()))
            urlToHash.forEach { (u, h) -> hashToUrls.getOrPut(h) { mutableSetOf() }.add(u) }
        }
    }

    @Synchronized
    fun put(url: String, bytes: ByteArray): String {
        val h = sha256Hex(bytes)
        val f = File(dir, h)
        if (!f.exists()) f.writeBytes(bytes)
        link(url, h)
        return h
    }

    /** Streaming store with incremental hashing (spec §32 — never load huge files into RAM). */
    @Synchronized
    fun putStream(url: String, input: InputStream, maxBytes: Long): Pair<String, Long> {
        val tmp = File(dir, ".tmp-${System.nanoTime()}")
        val digest = MessageDigest.getInstance("SHA-256")
        var total = 0L
        tmp.outputStream().buffered().use { out ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                total += n
                if (total > maxBytes) { tmp.delete(); throw SecurityGuard.LimitExceeded("response exceeds maxResponseSize") }
                digest.update(buf, 0, n)
                out.write(buf, 0, n)
            }
        }
        val h = digest.digest().joinToString("") { "%02x".format(it) }
        val dst = File(dir, h)
        if (dst.exists()) tmp.delete() else tmp.renameTo(dst)
        link(url, h)
        return h to total
    }

    @Synchronized
    private fun link(url: String, hash: String) {
        urlToHash[url] = hash
        hashToUrls.getOrPut(hash) { mutableSetOf() }.add(url)
        if (urlToHash.size % 25 == 0) persist()
    }

    fun has(url: String) = urlToHash.containsKey(url)
    fun hashOf(url: String) = urlToHash[url]
    fun artifactFile(hash: String) = File(dir, hash)
    fun bytes(hash: String): ByteArray? = artifactFile(hash).takeIf { it.exists() }?.readBytes()

    @Synchronized
    fun persist() = runCatching { mapFile.writeText(Json.encodeToString(urlToHash)) }

    fun totalBytes(): Long = dir.listFiles()?.filter { !it.name.startsWith(".tmp") }?.sumOf { it.length() } ?: 0L
    fun artifactCount(): Int = hashToUrls.size
}
