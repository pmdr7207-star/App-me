package com.extractor.wse.core

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

enum class DiscoveryMethod {
    HTML, STATIC_SCRIPT, STATIC_CSS, STATIC_ASSET, IMPORT, DYNAMIC_IMPORT,
    NETWORK, XHR, FETCH, WEBSOCKET, WORKER, SHARED_WORKER, SERVICE_WORKER,
    ROUTE, MANIFEST, SOURCE_MAP, META, IMPORT_MAP, OTHER
}

enum class NodeType {
    DOCUMENT, SCRIPT, STYLE, IMAGE, FONT, MEDIA, JSON, API, WORKER,
    SERVICE_WORKER, WASM, SOURCE_MAP, FRAME, ROUTE, OTHER
}

enum class EdgeType { IMPORTS, LOADS, CALLS, CREATES, MAPS_TO, REDIRECTS_TO, DISCOVERED_FROM, USED_BY, ROUTES_TO }

// Exactly one primary classification per artifact (spec §16)
enum class Classification {
    ORIGINAL_PUBLIC_SOURCE, SOURCE_MAP_CONFIRMED, DEPLOYED_SOURCE, BUNDLED_SOURCE,
    GENERATED_RESOURCE, RUNTIME_DISCOVERED, API_RESPONSE, BINARY_ASSET,
    INFERRED, UNAVAILABLE, ERROR
}

enum class Confidence { EXACT, SOURCE_MAP_CONFIRMED, NETWORK_CONFIRMED, DEPENDENCY_CONFIRMED, FRAMEWORK_INFERRED, HEURISTIC }

enum class ErrKind {
    FAILED, BLOCKED, AUTH_REQUIRED, NOT_FOUND, TIMEOUT, SERVER_ERROR,
    INVALID_CONTENT, PARSER_ERROR, SOURCE_MAP_ERROR, CROSS_ORIGIN_LIMIT,
    UNSUPPORTED, RESOURCE_CHANGED
}

enum class BatteryMode(val concurrency: Int, val label: String) {
    NORMAL(6, "Normal"), BALANCED(3, "Balanced"), DEEP(8, "Deep Extraction")
}

/** Immutable evidence record — one per discovered resource (spec §2). */
@Serializable
data class EvidenceRecord(
    val resourceId: String,
    val sourceUrl: String,
    var finalUrl: String = "",
    var origin: String = "",
    var discoveryMethod: String = "OTHER",
    var discoveryParent: String? = null,
    var httpStatus: Int = 0,
    var mimeType: String = "",
    var contentLength: Long = -1,
    var encoding: String = "",
    var etag: String? = null,
    var lastModified: String? = null,
    var sha256: String = "",
    var acquiredAt: Long = 0,
    var firstSeenAt: Long = 0,
    var lastSeenAt: Long = 0,
    var sourceClassification: String = "UNAVAILABLE",
    var authoredStatus: String = "UNKNOWN",     // AUTHORED / DEPLOYED / GENERATED / UNKNOWN
    var runtimeStatus: String = "UNKNOWN",      // RUNTIME / STATIC / BOTH
    var parserStatus: String = "NONE",
    var sourceMapStatus: String = "NONE",       // NONE / FOUND / VALIDATED / FAILED
    var confidence: String = "HEURISTIC",
    var nodeType: String = "OTHER",
    var secretDetected: Boolean = false,
    val errors: MutableList<String> = mutableListOf(),
    val warnings: MutableList<String> = mutableListOf()
)

@Serializable
data class ExtractionError(
    val kind: String,
    val stage: String,
    val resource: String,
    val message: String,
    val status: Int = 0,
    val retryCount: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    var finalState: String = "OPEN"
)

@Serializable
data class ApiObservation(
    val method: String,
    val url: String,
    val origin: String,
    val status: Int = 0,
    val contentType: String = "",
    val callerResource: String = "",
    val authState: String = "UNKNOWN",
    val timestamp: Long = System.currentTimeMillis(),
    val artifactHash: String? = null
)

@Serializable
data class RuntimeEvent(
    val type: String,      // navigation / network / fetch / xhr / websocket / worker / sw / route / console / jserror / dynamic-import
    val url: String,
    val detail: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Serializable
data class GraphEdge(val from: String, val to: String, val type: String)

@Serializable
data class FrameworkInfo(
    val name: String,
    val version: String? = null,   // never guessed — only when provable
    val evidence: String,
    val confidence: String
)

/** Deterministic snapshot — spec §20. */
@Serializable
data class Snapshot(
    val snapshotId: String,
    val targetUrl: String,
    val finalUrl: String,
    val timestamp: Long,
    val scope: String,
    val graphHash: String,
    val artifacts: Map<String, String>,          // normalizedUrl -> sha256
    val evidence: List<EvidenceRecord>,
    val edges: List<GraphEdge>,
    val apiInventory: List<ApiObservation>,
    val runtimeTrace: List<RuntimeEvent>,
    val frameworks: List<FrameworkInfo>,
    val completeness: Map<String, Double>,
    val completenessStatement: String,
    val backendVisibility: String,
    val errors: List<ExtractionError>,
    val warnings: List<String>
)

@Serializable
data class DiffResult(
    val added: List<String>,
    val removed: List<String>,
    val changed: List<String>,
    val unchanged: List<String>
)

@Serializable
data class Checkpoint(
    val target: String,
    val pending: List<PendingItem>,
    val seen: Set<String>,
    val evidence: List<EvidenceRecord>,
    val edges: List<GraphEdge>,
    val savedAt: Long = System.currentTimeMillis()
)

@Serializable
data class PendingItem(
    val url: String,
    val parent: String?,
    val method: String,
    val depth: Int
)

val json: Json = Json {
    prettyPrint = false
    ignoreUnknownKeys = true
    encodeDefaults = true
    explicitNulls = false
}

fun sha256Hex(data: ByteArray): String =
    java.security.MessageDigest.getInstance("SHA-256")
        .digest(data)
        .joinToString("") { "%02x".format(it) }

fun normalizeUrl(raw: String): String {
    val u = java.net.URI(raw.trim())
    val scheme = (u.scheme ?: "https").lowercase()
    val host = (u.host ?: return raw).lowercase()
    val port = u.port
    val defaultPort = (scheme == "http" && port == 80) || (scheme == "https" && port == 443)
    val path = if (u.rawPath.isNullOrEmpty()) "/" else u.rawPath
    val query = if (u.rawQuery.isNullOrEmpty()) "" else "?${u.rawQuery}"
    return buildString {
        append(scheme).append("://").append(host)
        if (port >= 0 && !defaultPort) append(':').append(port)
        append(path).append(query)
    }
}

fun originOf(url: String): String = try {
    val u = java.net.URI(url)
    "${u.scheme}://${u.host}${if (u.port >= 0) ":${u.port}" else ""}"
} catch (_: Exception) { "" }

fun resolveUrl(base: String, ref: String): String? = try {
    if (ref.startsWith("data:") || ref.startsWith("blob:") || ref.startsWith("javascript:")
        || ref.startsWith("mailto:") || ref.startsWith("tel:") || ref.startsWith("#")
    ) null
    else normalizeUrl(java.net.URI(base).resolve(ref.trim()).toString())
} catch (_: Exception) { null }
