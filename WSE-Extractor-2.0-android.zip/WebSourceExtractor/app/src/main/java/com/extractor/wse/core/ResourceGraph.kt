package com.extractor.wse.core

import java.util.concurrent.ConcurrentHashMap

/** Directed multi-graph: resources, routes, modules, workers, source maps (spec §6, §18). */
class ResourceGraph {

    val nodes = ConcurrentHashMap<String, EvidenceRecord>()
    val edges = ConcurrentHashMap.newKeySet<GraphEdge>()

    fun addNode(r: EvidenceRecord) {
        nodes.merge(r.resourceId, r) { old, new ->
            old.lastSeenAt = maxOf(old.lastSeenAt, new.lastSeenAt)
            // keep richest record (one with bytes/status wins)
            if (new.sha256.isNotEmpty()) old else old.copy()
            new.takeIf { it.sha256.isNotEmpty() } ?: old
        }
    }

    fun addEdge(from: String, to: String, type: EdgeType) = edges.add(GraphEdge(from, to, type.name))

    fun outgoing(id: String) = edges.filter { it.from == id }
    fun incoming(id: String) = edges.filter { it.to == id }

    /** Stable hash used by the convergence engine (spec §19). */
    fun stableHash(): String {
        val n = nodes.keys.sorted().joinToString("|")
        val e = edges.map { "${it.from}->${it.to}:${it.type}" }.sorted().joinToString("|")
        return sha256Hex((n + "##" + e).toByteArray())
    }

    fun byType(type: NodeType) = nodes.values.filter { it.nodeType == type.name }

    fun loadFrom(records: List<EvidenceRecord>, edgeList: List<GraphEdge>) {
        records.forEach { nodes[it.resourceId] = it }
        edges.addAll(edgeList)
    }
}
