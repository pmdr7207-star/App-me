package com.extractor.wse.core

import java.net.InetAddress

/**
 * Extractor self-protection (spec §30): SSRF guard, scheme allow-list,
 * and hard resource limits.
 */
object SecurityGuard {

    class LimitExceeded(msg: String) : Exception(msg)
    class BlockedTarget(msg: String) : Exception(msg)

    data class Limits(
        val maxResponseSize: Long = 50L * 1024 * 1024,
        val maxProjectSize: Long = 2L * 1024 * 1024 * 1024,
        val maxDepth: Int = 8,
        val maxUrls: Int = 20000,
        val maxDurationMs: Long = 45L * 60 * 1000,
        val maxRedirects: Int = 8,
        val maxConcurrency: Int = 8,
        val maxRoutes: Int = 200,
        val maxRuntimeMs: Long = 120_000
    )

    fun validate(url: String) {
        val lower = url.lowercase()
        if (!lower.startsWith("http://") && !lower.startsWith("https://"))
            throw BlockedTarget("scheme not allowed: $url")
        val host = java.net.URI(url).host ?: throw BlockedTarget("no host: $url")
        val h = host.lowercase()
        if (h == "localhost" || h.endsWith(".local") || h.endsWith(".internal"))
            throw BlockedTarget("local host blocked: $host")
        val addrs = runCatching { InetAddress.getAllByName(host) }.getOrElse { emptyArray() }
        for (a in addrs) {
            if (a.isLoopbackAddress || a.isLinkLocalAddress || a.isAnyLocalAddress || a.isSiteLocalAddress)
                throw BlockedTarget("private/loopback address blocked for $host (${a.hostAddress})")
            val ip = a.hostAddress ?: continue
            if (ip == "169.254.169.254" || ip.startsWith("fe80:") || ip.startsWith("fc") || ip.startsWith("fd"))
                throw BlockedTarget("metadata/reserved address blocked: $ip")
        }
    }

    fun inScope(url: String, scopeOrigin: String): Boolean =
        try { originOf(url) == scopeOrigin } catch (_: Exception) { false }

    fun checkProjectBudget(currentBytes: Long, limits: Limits) {
        if (currentBytes > limits.maxProjectSize) throw LimitExceeded("project size budget exceeded")
    }
}
