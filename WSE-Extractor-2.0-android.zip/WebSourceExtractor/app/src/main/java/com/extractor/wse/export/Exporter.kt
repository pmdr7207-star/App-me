package com.extractor.wse.export

import android.content.Context
import com.extractor.wse.acquire.StaticEngine
import com.extractor.wse.core.*
import com.extractor.wse.reconstruct.Reconstructor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Export engine (spec §23, §24): forensic-grade _extraction manifests,
 * reconstructed project tree, deployed artifacts, unified raw text,
 * and a deterministic ZIP. Binary artifacts are never concatenated
 * into text output.
 */
class Exporter(private val context: Context) {

    suspend fun exportAll(snapshot: Snapshot, store: ArtifactStore): File = withContext(Dispatchers.IO) {
        val dir = File(context.filesDir, "exports/${snapshot.snapshotId}").apply { mkdirs() }
        dir.deleteRecursively(); dir.mkdirs()

        val extraction = File(dir, "_extraction").apply { mkdirs() }
        val project = File(dir, "project").apply { mkdirs() }
        val deployed = File(dir, "deployed").apply { mkdirs() }
        val maps = File(dir, "source-maps").apply { mkdirs() }
        val network = File(dir, "network").apply { mkdirs() }

        fun w(f: File, s: String) { f.parentFile?.mkdirs(); f.writeText(s) }

        // --- _extraction manifests (§23) ---
        w(File(extraction, "evidence-ledger.json"), pretty(json.encodeToString(snapshot.evidence)))
        w(File(extraction, "resource-manifest.json"), pretty(json.encodeToString(snapshot.artifacts)))
        w(File(extraction, "dependency-graph.json"), pretty(json.encodeToString(snapshot.edges)))
        w(File(extraction, "route-graph.json"), pretty(json.encodeToString(
            snapshot.edges.filter { it.type == EdgeType.ROUTES_TO.name } +
                    snapshot.runtimeTrace.filter { it.type == "route" || it.type == "navigation" }
        )))
        w(File(extraction, "api-inventory.json"), pretty(json.encodeToString(snapshot.apiInventory)))
        w(File(extraction, "worker-inventory.json"), pretty(json.encodeToString(
            snapshot.evidence.filter { it.nodeType == NodeType.WORKER.name || it.nodeType == NodeType.SERVICE_WORKER.name }
        )))
        w(File(extraction, "source-map-report.json"), pretty(json.encodeToString(
            snapshot.evidence.filter { it.nodeType == NodeType.SOURCE_MAP.name || it.sourceClassification == Classification.SOURCE_MAP_CONFIRMED.name }
        )))
        w(File(extraction, "backend-visibility.json"), pretty(json.encodeToString(mapOf(
            "visibility" to snapshot.backendVisibility,
            "note" to "Backend source is never inferred from API responses.",
            "endpoints" to snapshot.apiInventory.size.toString()
        ))))
        w(File(extraction, "errors.json"), pretty(json.encodeToString(snapshot.errors)))
        w(File(extraction, "warnings.json"), pretty(json.encodeToString(snapshot.warnings)))
        w(File(extraction, "runtime-trace.json"), pretty(json.encodeToString(snapshot.runtimeTrace)))
        w(File(extraction, "completeness-report.json"), pretty(json.encodeToString(mapOf(
            "statement" to snapshot.completenessStatement,
            "metrics" to snapshot.completeness.map { (k, v) -> "$k" to "%.1f".format(v) }.toMap(),
            "frameworks" to snapshot.frameworks.map { "${it.name} (${it.confidence}${it.version?.let { v -> " v$v" } ?: ""})" }
        ))))
        w(File(extraction, "README.txt"), readme(snapshot))

        // hashes.sha256 — integrity manifest (§22)
        val hashLines = snapshot.artifacts.entries.sortedBy { it.key }
            .joinToString("\n") { (url, h) -> "$h  $url" }
        w(File(extraction, "hashes.sha256"), hashLines)

        // --- project/ reconstructed tree ---
        val tree = Reconstructor.build(snapshot)
        writeTree(tree, project, store)

        // --- deployed/ original artifacts by URL path ---
        for ((url, h) in snapshot.artifacts) {
            if (url.startsWith("sourcemap://")) continue
            val bytes = store.bytes(h) ?: continue
            val path = runCatching { java.net.URI(url).path?.trim('/') }.getOrNull().orEmpty()
                .ifEmpty { "index.html" }.replace("..", "_")
            val f = File(deployed, path)
            f.parentFile?.mkdirs()
            f.writeBytes(bytes)
            if (url.endsWith(".map")) f.copyTo(File(maps, f.name), overwrite = true)
        }

        // --- network/ API metadata ---
        snapshot.apiInventory.forEachIndexed { i, api ->
            w(File(network, "api-%03d.json".format(i)), pretty(json.encodeToString(api)))
        }

        // --- unified raw output (§24) ---
        val raw = StringBuilder()
        for (rec in snapshot.evidence.filter { it.sha256.isNotEmpty() && StaticEngine.isText(it.mimeType) }
            .sortedBy { it.resourceId }) {
            val bytes = store.bytes(rec.sha256) ?: continue
            if (bytes.size > 2_000_000) continue // huge single files stay in deployed/
            raw.append("===== FILE: ").append(rec.resourceId).append(" =====\n")
            raw.append("metadata:\n  URL: ").append(rec.finalUrl.ifEmpty { rec.sourceUrl })
                .append("\n  SHA256: ").append(rec.sha256)
                .append("\n  classification: ").append(rec.sourceClassification)
                .append("\n  confidence: ").append(rec.confidence)
                .append("\n  mime: ").append(rec.mimeType)
                .append("\n  size: ").append(rec.contentLength).append("\n\n")
            raw.append(com.extractor.wse.acquire.JsAnalyzer.redactAll(String(bytes, Charsets.UTF_8)))
            raw.append("\n\n")
        }
        w(File(dir, "unified-raw.txt"), raw.toString())

        // --- ZIP ---
        val zip = File(context.filesDir, "exports/${snapshot.snapshotId}.zip")
        ZipOutputStream(zip.outputStream().buffered()).use { z ->
            dir.walkTopDown().filter { it.isFile }.forEach { f ->
                z.putNextEntry(ZipEntry(f.relativeTo(dir).path))
                f.inputStream().use { it.copyTo(z) }
                z.closeEntry()
            }
        }
        zip
    }

    private fun writeTree(node: Reconstructor.ProjectNode, dir: File, store: ArtifactStore) {
        if (node.isDir) {
            val d = if (node.path.isEmpty()) dir else File(dir, node.name)
            d.mkdirs()
            node.children.values.forEach { writeTree(it, d, store) }
        } else {
            val name = node.name.replace("..", "_")
            val bytes = node.artifactHash?.let { store.bytes(it) } ?: return
            File(dir, name).writeBytes(bytes)
        }
    }

    private fun pretty(s: String): String = runCatching {
        val p = Json { prettyPrint = true; ignoreUnknownKeys = true }
        p.encodeToString(kotlinx.serialization.json.JsonElement.serializer(), json.parseToJsonElement(s))
    }.getOrDefault(s)

    private fun readme(s: Snapshot): String = """
        WSE Extractor 2.0 — Evidence-Driven Extraction
        Snapshot: ${s.snapshotId}
        Target: ${s.targetUrl}
        Time: ${java.util.Date(s.timestamp)}
        
        ${s.completenessStatement}
        ${s.backendVisibility}
        
        RULES (spec §44):
        - No evidence = no claim.
        - INFERRED paths are marked; never treated as fact.
        - "DEPLOYED BUNDLE ONLY" is reported instead of pretending original source was recovered.
        - Everything in this archive is reproducible from evidence-ledger.json.
        - Secrets are redacted by default (spec §15).
    """.trimIndent()
}
