package com.extractor.wse.acquire

import com.extractor.wse.core.*

/** Framework detection (spec §11): evidence-based only, never guessed versions. */
object FrameworkDetector {

    private val markers = listOf(
        Triple("Next.js", "__NEXT_DATA__", Confidence.EXACT),
        Triple("Next.js", "/_next/static/", Confidence.EXACT),
        Triple("Nuxt", "__NUXT__", Confidence.EXACT),
        Triple("Nuxt", "/_nuxt/", Confidence.NETWORK_CONFIRMED),
        Triple("React", "data-reactroot", Confidence.NETWORK_CONFIRMED),
        Triple("React", "__REACT_DEVTOOLS_GLOBAL_HOOK__", Confidence.FRAMEWORK_INFERRED),
        Triple("React Native Web", "react-native-web", Confidence.DEPENDENCY_CONFIRMED),
        Triple("Expo", "__expo", Confidence.NETWORK_CONFIRMED),
        Triple("Expo Router", "expo-router", Confidence.DEPENDENCY_CONFIRMED),
        Triple("Vue", "__VUE__", Confidence.NETWORK_CONFIRMED),
        Triple("Vue", "data-v-", Confidence.FRAMEWORK_INFERRED),
        Triple("Angular", "ng-version", Confidence.EXACT),
        Triple("Angular", "ng-app", Confidence.NETWORK_CONFIRMED),
        Triple("Svelte", "__svelte", Confidence.NETWORK_CONFIRMED),
        Triple("SvelteKit", "__sveltekit", Confidence.EXACT),
        Triple("Astro", "astro-island", Confidence.EXACT),
        Triple("Vite", "/@vite/client", Confidence.EXACT),
        Triple("Vite", "import.meta.hot", Confidence.DEPENDENCY_CONFIRMED),
        Triple("Webpack", "__webpack_require__", Confidence.EXACT),
        Triple("Webpack", "webpackChunk", Confidence.NETWORK_CONFIRMED),
        Triple("Rollup", "rollupPlugin", Confidence.FRAMEWORK_INFERRED),
        Triple("Parcel", "parcelRequire", Confidence.EXACT),
        Triple("Remix", "__remixContext", Confidence.EXACT)
    )

    fun detect(evidence: List<EvidenceRecord>, store: ArtifactStore): List<FrameworkInfo> {
        val found = LinkedHashMap<String, FrameworkInfo>()
        // URL-level evidence
        for (e in evidence) {
            for ((name, marker, conf) in markers) {
                if (e.resourceId.contains(marker, true) || e.finalUrl.contains(marker, true)) {
                    found.merge(name, FrameworkInfo(name, null, "URL: ${e.resourceId}", conf.name)) { a, b ->
                        if (rank(b.confidence) > rank(a.confidence)) b else a
                    }
                }
            }
        }
        // content-level evidence (only text artifacts, sampled)
        for (e in evidence.filter { it.sha256.isNotEmpty() && StaticEngine.isText(it.mimeType) }.take(200)) {
            val text = store.bytes(e.sha256)?.let { String(it, Charsets.UTF_8) } ?: continue
            for ((name, marker, conf) in markers) {
                if (text.contains(marker)) {
                    found.merge(name, FrameworkInfo(name, null, "content marker '$marker' in ${e.resourceId}", conf.name)) { a, b ->
                        if (rank(b.confidence) > rank(a.confidence)) b else a
                    }
                }
            }
            // provable version: only Angular ng-version attribute
            Regex("""ng-version="([^"]+)"""").find(text)?.let { m ->
                found["Angular"] = FrameworkInfo("Angular", m.groupValues[1], "ng-version attribute", Confidence.EXACT.name)
            }
        }
        return found.values.toList()
    }

    private fun rank(c: String) = when (c) {
        Confidence.EXACT.name -> 5
        Confidence.SOURCE_MAP_CONFIRMED.name -> 4
        Confidence.NETWORK_CONFIRMED.name -> 3
        Confidence.DEPENDENCY_CONFIRMED.name -> 2
        Confidence.FRAMEWORK_INFERRED.name -> 1
        else -> 0
    }
}
