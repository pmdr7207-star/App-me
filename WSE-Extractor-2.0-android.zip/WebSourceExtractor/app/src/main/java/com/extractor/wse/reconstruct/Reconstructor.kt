package com.extractor.wse.reconstruct

import com.extractor.wse.core.*

/**
 * Reconstruction engine (spec §17): hierarchy rebuilt in strict priority —
 * source-map paths > real URLs > imports > inference. Every inferred path
 * is marked INFERRED and never silently promoted to fact.
 */
object Reconstructor {

    data class ProjectNode(
        val path: String,
        val name: String,
        val isDir: Boolean,
        val artifactHash: String? = null,
        val classification: String = "",
        val confidence: String = "",
        val inferred: Boolean = false,
        val mimeType: String = "",
        val size: Long = 0,
        val urls: List<String> = emptyList(),
        val children: MutableMap<String, ProjectNode> = mutableMapOf()
    )

    fun build(snapshot: Snapshot): ProjectNode {
        val root = ProjectNode("", "project", true)

        fun insert(path: String, rec: EvidenceRecord, inferred: Boolean) {
            val parts = path.split('/').filter { it.isNotBlank() && it != "." }
            if (parts.isEmpty()) return
            var node = root
            var built = ""
            for (i in parts.indices) {
                val seg = parts[i]
                built = if (built.isEmpty()) seg else "$built/$seg"
                val last = i == parts.lastIndex
                node = node.children.getOrPut(seg) {
                    ProjectNode(
                        path = built, name = seg, isDir = !last,
                        inferred = if (last) inferred else true,
                        classification = if (last) rec.sourceClassification else "INFERRED",
                        confidence = if (last) rec.confidence else Confidence.HEURISTIC.name
                    )
                }
                if (last && !node.isDir) {
                    // fill leaf metadata
                    val idx = parts.lastIndex
                    node.children // no-op; leaf already created with metadata below
                }
            }
            // overwrite leaf with real metadata
            val leaf = find(root, parts) ?: return
            val real = leaf.copy(
                isDir = false,
                artifactHash = rec.sha256.ifEmpty { null },
                classification = rec.sourceClassification,
                confidence = rec.confidence,
                inferred = inferred,
                mimeType = rec.mimeType,
                size = rec.contentLength,
                urls = listOf(rec.finalUrl.ifEmpty { rec.sourceUrl })
            )
            replace(root, parts, real)
        }

        // 1) source-map confirmed authored files — highest priority
        snapshot.evidence
            .filter { it.sourceClassification == Classification.SOURCE_MAP_CONFIRMED.name }
            .forEach { rec ->
                val path = rec.resourceId.substringAfter('!', "")
                if (path.isNotEmpty()) insert(path, rec, inferred = false)
            }

        // 2) real deployed resources by URL path
        snapshot.evidence
            .filter { it.sha256.isNotEmpty() && it.sourceClassification != Classification.SOURCE_MAP_CONFIRMED.name }
            .forEach { rec ->
                val u = rec.finalUrl.ifEmpty { rec.sourceUrl }
                val path = runCatching { java.net.URI(u).path?.trim('/') }.getOrNull().orEmpty()
                if (path.isNotEmpty()) {
                    val withHint = if ('.' in path.substringAfterLast('/')) path else "$path/index.html"
                    if (find(root, withHint.split('/').filter { it.isNotBlank() }) == null)
                        insert(withHint, rec, inferred = false)
                }
            }

        // 3) inference placeholders for import targets never acquired
        snapshot.edges.filter { it.type == EdgeType.IMPORTS.name }.forEach { e ->
            val target = e.to
            val exists = snapshot.evidence.any { it.resourceId == target && it.sha256.isNotEmpty() }
            if (!exists) {
                val ghost = EvidenceRecord(
                    resourceId = target, sourceUrl = target,
                    sourceClassification = Classification.INFERRED.name,
                    confidence = Confidence.HEURISTIC.name
                )
                val path = runCatching { java.net.URI(target).path?.trim('/') }.getOrNull()
                    ?: target.substringAfterLast('/')
                if (path.isNotEmpty()) insert("$path (INFERRED — not acquired)", ghost, inferred = true)
            }
        }
        return root
    }

    private fun find(root: ProjectNode, parts: List<String>): ProjectNode? {
        var n = root
        for (p in parts) { n = n.children[p] ?: return null }
        return n
    }

    private fun replace(root: ProjectNode, parts: List<String>, node: ProjectNode) {
        if (parts.isEmpty()) return
        if (parts.size == 1) { root.children[parts[0]] = node; return }
        val parent = find(root, parts.dropLast(1)) ?: return
        parent.children[parts.last()] = node
    }

    /** Flatten for a virtualized list (§25 — never materialize 100k DOM nodes). */
    fun flatten(root: ProjectNode, expanded: Set<String>, query: String): List<Pair<ProjectNode, Int>> {
        val out = mutableListOf<Pair<ProjectNode, Int>>()
        fun matches(n: ProjectNode): Boolean =
            query.isBlank() || n.name.contains(query, true) || n.children.values.any { matches(it) }
        fun walk(n: ProjectNode, depth: Int) {
            if (!matches(n)) return
            out.add(n to depth)
            if (n.isDir && (query.isNotBlank() || n.path in expanded)) {
                n.children.values.sortedWith(compareBy({ !it.isDir }, { it.name.lowercase() }))
                    .forEach { walk(it, depth + 1) }
            }
        }
        root.children.values.sortedWith(compareBy({ !it.isDir }, { it.name.lowercase() }))
            .forEach { walk(it, 0) }
        return out
    }
}
