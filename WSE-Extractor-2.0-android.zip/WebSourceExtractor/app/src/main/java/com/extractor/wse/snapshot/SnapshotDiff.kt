package com.extractor.wse.snapshot

import com.extractor.wse.core.DiffResult
import com.extractor.wse.core.Snapshot

/** Snapshot diff (spec §20): added / removed / changed / unchanged between deploys. */
object SnapshotDiff {
    fun diff(a: Snapshot, b: Snapshot): DiffResult {
        val added = mutableListOf<String>()
        val removed = mutableListOf<String>()
        val changed = mutableListOf<String>()
        val unchanged = mutableListOf<String>()
        for ((url, hash) in b.artifacts) {
            val old = a.artifacts[url]
            when {
                old == null -> added.add(url)
                old != hash -> changed.add(url)
                else -> unchanged.add(url)
            }
        }
        for (url in a.artifacts.keys) if (url !in b.artifacts) removed.add(url)
        return DiffResult(added.sorted(), removed.sorted(), changed.sorted(), unchanged.sorted())
    }
}
