package com.extractor.wse.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.extractor.wse.core.BatteryMode
import com.extractor.wse.work.ExtractionBus
import com.extractor.wse.work.ExtractionWorker

enum class Screen { HOME, RUN, RESULT }

@Composable
fun App() {
    val dark = isSystemInDarkTheme()
    val scheme = if (dark) darkColorScheme() else lightColorScheme()
    MaterialTheme(colorScheme = scheme) {
        Surface(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
            Navigator()
        }
    }
}

@Composable
fun Navigator() {
    var screen by remember { mutableStateOf(Screen.HOME) }
    val progress by ExtractionBus.progress.collectAsStateWithLifecycle()
    val snapshot by ExtractionBus.lastSnapshot.collectAsStateWithLifecycle()

    // predictive-back compatible navigation (BackHandler -> OnBackPressedDispatcher)
    BackHandler(enabled = screen != Screen.HOME) {
        screen = if (screen == Screen.RESULT && progress.running) Screen.RUN else Screen.HOME
    }
    LaunchedEffect(progress.done) { if (progress.done && snapshot != null) screen = Screen.RESULT }

    when (screen) {
        Screen.HOME -> HomeScreen { screen = Screen.RUN }
        Screen.RUN -> RunScreen(onDone = { screen = Screen.RESULT })
        Screen.RESULT -> ResultScreen()
    }
}

@Composable
fun HomeScreen(onStart: () -> Unit) {
    val context = LocalContext.current
    var url by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf(BatteryMode.NORMAL) }
    val fatal by ExtractionBus.fatal.collectAsStateWithLifecycle()

    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    Column(
        Modifier.fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("WSE Extractor", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(
            "Evidence-driven web project acquisition.\nEVIDENCE FIRST. RECONSTRUCTION SECOND. INFERENCE LAST.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        OutlinedTextField(
            value = url,
            onValueChange = { url = it },
            label = { Text("Authorized target URL") },
            placeholder = { Text("https://example.com") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
            modifier = Modifier.fillMaxWidth()
        )

        Text("Battery / extraction mode", style = MaterialTheme.typography.labelLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BatteryMode.entries.forEach { m ->
                if (m == mode) Button(onClick = {}, modifier = Modifier.height(48.dp)) { Text(m.label) }
                else OutlinedButton(onClick = { mode = m }, modifier = Modifier.height(48.dp)) { Text(m.label) }
            }
        }

        Button(
            onClick = {
                val t = url.trim()
                if (t.startsWith("http")) {
                    ExtractionBus.fatal.value = null
                    ExtractionWorker.enqueue(context, t, mode)
                    onStart()
                }
            },
            enabled = url.trim().startsWith("http"),
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) { Text("Start extraction") }

        fatal?.let {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                Text("Last run failed: $it", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onErrorContainer)
            }
        }

        Text(
            "Only crawl applications you are authorized to analyze. The engine never bypasses authentication, never submits forms, and blocks private/metadata addresses.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun RunScreen(onDone: () -> Unit) {
    val context = LocalContext.current
    val p by ExtractionBus.progress.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Extraction", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(p.pass, color = MaterialTheme.colorScheme.primary)
        if (p.running) LinearProgressIndicator(Modifier.fillMaxWidth())

        val stats = listOf(
            "Discovered" to p.discovered, "Queued" to p.queued, "Completed" to p.completed,
            "Bytes" to p.bytes / 1024, "JS" to p.js, "CSS" to p.css, "Maps" to p.maps,
            "Workers" to p.workers, "Routes" to p.routes, "APIs" to p.apis,
            "Errors" to p.errors, "Warnings" to p.warnings
        )
        LazyVerticalGrid(
            columns = GridCells.Adaptive(140.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(stats.size) { i ->
                val (label, value) = stats[i]
                Card {
                    Column(Modifier.padding(12.dp)) {
                        Text(label, style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            if (label == "Bytes") "${value} KB" else "$value",
                            style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (p.running) {
                OutlinedButton(onClick = { ExtractionWorker.cancel(context) }, Modifier.height(48.dp)) {
                    Text("Stop (checkpoint saved)")
                }
            }
            if (p.done) {
                Button(onClick = onDone, Modifier.height(48.dp)) { Text("View results") }
            }
        }
        Text("Progress reflects real task state — never simulated.", style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
