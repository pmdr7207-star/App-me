package com.extractor.wse.ui

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.extractor.wse.acquire.Orchestrator
import com.extractor.wse.acquire.StaticEngine
import com.extractor.wse.core.ArtifactStore
import com.extractor.wse.core.Snapshot
import com.extractor.wse.export.Exporter
import com.extractor.wse.reconstruct.Reconstructor
import com.extractor.wse.snapshot.SnapshotDiff
import com.extractor.wse.work.ExtractionBus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class Tab(val label: String) { TREE("Project"), REPORTS("Reports"), DIFF("Diff") }

private fun storeFor(context: Context, snapshot: Snapshot): ArtifactStore? {
    val pair = Orchestrator.listSnapshots(context).firstOrNull { it.second.snapshotId == snapshot.snapshotId }
    return pair?.first?.parentFile?.let { ArtifactStore(it) }
}

/** §36 — adaptive: compact = stacked tabs; expanded = TREE | SOURCE | METADATA. */
@Composable
fun ResultScreen() {
    val snapshot by ExtractionBus.lastSnapshot.collectAsStateWithLifecycle()
    val snap = snapshot ?: run {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No snapshot loaded") }
        return
    }
    val context = LocalContext.current
    val store = remember(snap.snapshotId) { storeFor(context, snap) }
    val tree = remember(snap.snapshotId) { Reconstructor.build(snap) }

    var tab by remember { mutableStateOf(Tab.TREE) }
    var selected by remember { mutableStateOf<Reconstructor.ProjectNode?>(null) }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val expanded = maxWidth >= 840.dp
        if (expanded) {
            Row(Modifier.fillMaxSize()) {
                Column(Modifier.width(300.dp).fillMaxHeight()) { TreePane(tree, store, onSelect = { selected = it }) }
                VerticalDivider()
                Column(Modifier.weight(1f).fillMaxHeight()) { SourcePane(selected, store) }
                VerticalDivider()
                Column(Modifier.width(320.dp).fillMaxHeight()) { MetadataPane(selected, snap, store) }
            }
        } else {
            Scaffold(
                bottomBar = {
                    NavigationBar {
                        Tab.entries.forEach { t ->
                            NavigationBarItem(
                                selected = tab == t,
                                onClick = { tab = t },
                                icon = { Text(t.label.take(1)) },
                                label = { Text(t.label) }
                            )
                        }
                    }
                }
            ) { pad ->
                Box(Modifier.padding(pad)) {
                    when (tab) {
                        Tab.TREE -> Row(Modifier.fillMaxSize()) {
                            Column(Modifier.weight(1f)) { TreePane(tree, store, onSelect = { selected = it }) }
                            if (selected != null) {
                                VerticalDivider()
                                Column(Modifier.weight(1f)) { SourcePane(selected, store) }
                            }
                        }
                        Tab.REPORTS -> ReportsPane(snap, store)
                        Tab.DIFF -> DiffPane(snap)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TreePane(
    root: Reconstructor.ProjectNode,
    store: ArtifactStore?,
    onSelect: (Reconstructor.ProjectNode) -> Unit
) {
    val clipboard = LocalClipboardManager.current
    var query by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(setOf<String>()) }

    Column(Modifier.fillMaxSize().padding(8.dp)) {
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            label = { Text("Search files") }, singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        val flat = remember(root, expanded, query) { Reconstructor.flatten(root, expanded, query) }
        // §25 — virtualized: LazyColumn only materializes visible rows
        LazyColumn(Modifier.fillMaxSize()) {
            items(flat.size, key = { flat[it].first.path + it }) { i ->
                val (node, depth) = flat[i]
                Row(
                    Modifier
                        .fillMaxWidth()
                        .combinedClickable(
                            onClick = {
                                if (node.isDir) expanded =
                                    if (node.path in expanded) expanded - node.path else expanded + node.path
                                else onSelect(node)
                            },
                            onLongClick = { clipboard.setText(AnnotatedString(node.path)) }
                        )
                        .padding(start = (depth * 14).dp, top = 8.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (node.isDir) {
                        Icon(
                            if (node.path in expanded) Icons.Default.KeyboardArrowDown else Icons.Default.KeyboardArrowRight,
                            contentDescription = if (node.path in expanded) "Collapse" else "Expand",
                            modifier = Modifier.size(20.dp)
                        )
                    } else Spacer(Modifier.width(20.dp))
                    Spacer(Modifier.width(6.dp))
                    Column {
                        Text(
                            node.name,
                            fontWeight = if (node.isDir) FontWeight.Bold else FontWeight.Normal,
                            color = if (node.inferred) MaterialTheme.colorScheme.error
                            else MaterialTheme.colorScheme.onSurface
                        )
                        if (node.inferred) Text(
                            "INFERRED — not acquired",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SourcePane(node: Reconstructor.ProjectNode?, store: ArtifactStore?) {
    val clipboard = LocalClipboardManager.current
    var content by remember(node?.path) { mutableStateOf<String?>(null) }
    LaunchedEffect(node?.path) {
        content = null
        if (node != null && store != null && node.artifactHash != null) {
            content = withContext(Dispatchers.IO) {
                val b = store.bytes(node.artifactHash) ?: return@withContext "UNAVAILABLE — bytes not found"
                if (!StaticEngine.isText(node.mimeType)) "BINARY ASSET — export to view (${b.size} bytes)"
                else if (b.size > 300_000) String(b.copyOf(300_000), Charsets.UTF_8) +
                        "\n\n… [lazy-truncated at 300KB — full file in export]"
                else String(b, Charsets.UTF_8)
            }
        }
    }
    Column(Modifier.fillMaxSize().padding(8.dp)) {
        if (node == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Select a file") }
            return@Column
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(node.path, Modifier.weight(1f), style = MaterialTheme.typography.labelLarge, maxLines = 1)
            TextButton(onClick = { clipboard.setText(AnnotatedString(content ?: "")) }) { Text("Copy") }
        }
        HorizontalDivider()
        SelectionContainer(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).horizontalScroll(rememberScrollState())) {
            Text(content ?: "Loading…", fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun MetadataPane(node: Reconstructor.ProjectNode?, snap: Snapshot, store: ArtifactStore?) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Metadata", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (node != null) {
            listOf(
                "path" to node.path,
                "classification" to node.classification,
                "confidence" to node.confidence,
                "inferred" to node.inferred.toString(),
                "mime" to node.mimeType,
                "size" to "${node.size} B",
                "sha256" to (node.artifactHash ?: "—"),
                "url" to node.urls.joinToString("\n")
            ).forEach { (k, v) ->
                Text(k, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                SelectionContainer { Text(v, style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace) }
            }
        }
        HorizontalDivider()
        ExportSection(snap, store)
    }
}

@Composable
private fun ExportSection(snap: Snapshot, store: ArtifactStore?) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var exporting by remember { mutableStateOf(false) }
    var zipPath by remember { mutableStateOf<String?>(null) }

    Text("Export", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
    Button(
        enabled = !exporting && store != null,
        onClick = {
            scope.launch {
                exporting = true
                val zip = Exporter(context).exportAll(snap, store!!)
                zipPath = zip.absolutePath
                exporting = false
                val uri = FileProvider.getUriForFile(context, "com.extractor.wse.fileprovider", zip)
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "application/zip"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(intent, "Share extraction ZIP"))
            }
        },
        modifier = Modifier.fillMaxWidth().height(48.dp)
    ) { Text(if (exporting) "Exporting…" else "Export ZIP + share") }
    zipPath?.let { Text(it, style = MaterialTheme.typography.labelSmall) }
}

@Composable
private fun ReportsPane(snap: Snapshot, store: ArtifactStore?) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {

        Text("Completeness", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(snap.completenessStatement, style = MaterialTheme.typography.bodySmall)
        snap.completeness.forEach { (k, v) ->
            Column {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(k, style = MaterialTheme.typography.labelMedium)
                    Text("%.1f%%".format(v), style = MaterialTheme.typography.labelMedium)
                }
                LinearProgressIndicator(progress = { (v / 100).toFloat() }, modifier = Modifier.fillMaxWidth())
            }
        }

        HorizontalDivider()
        Text("Backend visibility", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(snap.backendVisibility, style = MaterialTheme.typography.bodySmall)

        if (snap.frameworks.isNotEmpty()) {
            HorizontalDivider()
            Text("Frameworks", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            snap.frameworks.forEach {
                Text("• ${it.name}${it.version?.let { v -> " v$v" } ?: ""} — ${it.confidence} (${it.evidence})",
                    style = MaterialTheme.typography.bodySmall)
            }
        }

        HorizontalDivider()
        Text("API inventory (${snap.apiInventory.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        snap.apiInventory.take(50).forEach {
            Text("${it.method} ${it.url} [${it.status}]", style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
        }

        if (snap.errors.isNotEmpty()) {
            HorizontalDivider()
            Text("Errors (${snap.errors.size}) — never silently ignored", style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
            snap.errors.take(50).forEach {
                Text("[${it.kind}] ${it.resource}: ${it.message}", style = MaterialTheme.typography.bodySmall)
            }
        }
        if (snap.warnings.isNotEmpty()) {
            HorizontalDivider()
            Text("Warnings (${snap.warnings.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            snap.warnings.take(50).forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
        }

        HorizontalDivider()
        ExportSection(snap, store)
    }
}

@Composable
private fun DiffPane(current: Snapshot) {
    val context = LocalContext.current
    val others = remember { Orchestrator.listSnapshots(context).map { it.second }.filter { it.snapshotId != current.snapshotId } }
    var picked by remember { mutableStateOf<Snapshot?>(null) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Snapshot diff", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("Compare ${current.snapshotId} against:", style = MaterialTheme.typography.bodySmall)
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(others.size) { i ->
                val s = others[i]
                Card(Modifier.fillMaxWidth().clickable { picked = s }) {
                    Text("${s.snapshotId} — ${s.targetUrl}", Modifier.padding(12.dp))
                }
            }
        }
        picked?.let { old ->
            val d = remember(old, current) { SnapshotDiff.diff(old, current) }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("vs ${old.snapshotId}", fontWeight = FontWeight.Bold)
                    Text("added: ${d.added.size}   removed: ${d.removed.size}   changed: ${d.changed.size}   unchanged: ${d.unchanged.size}")
                    (d.added.take(10).map { "+ $it" } + d.removed.take(10).map { "- $it" } + d.changed.take(10).map { "~ $it" })
                        .forEach { Text(it, style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace) }
                }
            }
        }
    }
}
