package com.extractor.wse.work

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.work.*
import com.extractor.wse.acquire.Orchestrator
import com.extractor.wse.core.BatteryMode
import com.extractor.wse.core.Snapshot
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow

/** Process-wide bus so the UI can observe a worker-owned extraction (§34). */
object ExtractionBus {
    val progress = MutableStateFlow(Orchestrator.Progress())
    val lastSnapshot = MutableStateFlow<Snapshot?>(null)
    val fatal = MutableStateFlow<String?>(null)
}

/**
 * Android-16-compliant background execution (§34): expedited WorkManager
 * job with dataSync foreground-service type, checkpoint-safe, cancellable.
 * No permanent foreground service is created.
 */
class ExtractionWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun getForegroundInfo(): ForegroundInfo {
        createChannel(applicationContext)
        val n = Notification.Builder(applicationContext, CHANNEL)
            .setContentTitle("WSE extraction running")
            .setContentText("Evidence acquisition in progress — resumable")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true)
            .build()
        return if (Build.VERSION.SDK_INT >= 34)
            ForegroundInfo(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else ForegroundInfo(ID, n)
    }

    override suspend fun doWork(): Result {
        val target = inputData.getString("target") ?: return Result.failure()
        val mode = inputData.getString("mode") ?: BatteryMode.NORMAL.name
        setForeground(getForegroundInfo())
        val orch = Orchestrator(applicationContext)
        return try {
            val snap = kotlinx.coroutines.coroutineScope {
                val mirror = kotlinx.coroutines.launch {
                    orch.progress.collect { ExtractionBus.progress.value = it }
                }
                val s = orch.run(target, BatteryMode.valueOf(mode), resume = true)
                mirror.cancel()
                s
            }
            ExtractionBus.lastSnapshot.value = snap
            Result.success(workDataOf("snapshotId" to snap.snapshotId))
        } catch (e: CancellationException) {
            throw e // checkpoint already persisted — next run resumes
        } catch (e: Exception) {
            ExtractionBus.fatal.value = "${e.javaClass.simpleName}: ${e.message}"
            Result.retry().takeIf { runAttemptCount < 2 } ?: Result.failure()
        }
    }

    companion object {
        const val CHANNEL = "wse-extraction"
        const val ID = 42
        private const val WORK_NAME = "wse-extraction"

        fun enqueue(context: Context, target: String, mode: BatteryMode) {
            val req = OneTimeWorkRequestBuilder<ExtractionWorker>()
                .setInputData(workDataOf("target" to target, "mode" to mode.name))
                .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
                .build()
            WorkManager.getInstance(context).enqueueUniqueWork(
                WORK_NAME, ExistingWorkPolicy.REPLACE, req
            )
        }

        fun cancel(context: Context) =
            WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)

        private fun createChannel(context: Context) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Extraction", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }
}
